#pragma once
#include <iostream>
#include "Utils.h"
#include"MoveFunction.h"

class MoveFunction {
public:
	MoveFunction();
	~MoveFunction();

	//读取现在的角度，存到joint_pos中
	int GetJointPos(Array& cur_joint_pos, Array PUU);


	//功能函数：读取当前位置，移动到关节位置。插补结果存在DataPoint中
	void Myhrtapi_MoveToTarget_PutJoint(Array endJoint, double period, Array_2& DataPoint);
	//功能函数：读取当前位置，移动到直线起点，进行直线平移。插补结果存在DataPoint中
	void Myhrtapi_Moveline(Array StartJoint, Array EndJoint, double period, double size, Array_2& DataPoint);
	//功能函数：三点圆弧插补：读取当前位置，以关节插补移动到圆弧起点，进行三点圆弧插补
	void Myhrtapi_MoveCircular(Array StartJoint, Array Midjoint, Array endJoint, double period, double size, Array_2& DataPoint);
	//功能函数：回原点，从任何位置回到关节角度0，0，0，0，0，0。插补结果存在DataPoint中
	void Myhrtapi_MoveToZero(Array_2& DataPoint);



	//将两个过程的插补结果拼接，结果为返回值数组
	Array_2 Myhrtapi_Montage(Array_2 DataPoint1, Array_2 DataPoint2);
	//将关节角度转化为使用者单位PUU
	Array_2 Myhrtapi_Angle2PUU(Array_2 Data);
	//将使用者单位PUU转化为各关节角度
	Array Myhrtapi_PUU2Angle(Array PUU);


};