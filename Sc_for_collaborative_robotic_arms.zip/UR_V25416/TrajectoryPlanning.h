#pragma once

#include "Kinematics.h"



// 存放每个时间对应状态的类
typedef class
{
public:
    // 位置
    double positon;
    // 时间
    double time;
    // 速度
    double velocity;
    // 加速度
    double acceleration;
} Data;
// 存放带欧拉角的坐标
typedef class
{
public:
    // 位置
    double X;
    double Y;
    double Z;
    // 角度
    double Roll;
    double Pitch;
    double Yaw;
}Coordinate;

typedef std::vector<Data> DataArray;//二维data数组
typedef std::vector<Coordinate> CoordinateArray;//二维CoordinateArray数组

class TrajectoryPlanning {
public:
    TrajectoryPlanning();
    ~TrajectoryPlanning();
    Kinematics  trajKine;

    /*
     * 梯形规划函数，其中所有的值都应该为矢量
     */
    DataArray ComponentsPlanning(
        // 起始位置（矢量）
        double startPosition,
        // 起始速度（矢量）
        double startVelocity,
        // 起始加速度（矢量）
        double startAcceleration,
        // 终止位置（矢量）
        double endPosition,
        // 终止速度（矢量）
        double endVelocity,
        // 终止加速度（矢量）
        double endAcceleration,
        // 最大速度（矢量）
        double maxVelocity,
        // 加速度（矢量）
        double acceleration,
        // 插补周期
        double period);


    /*定步长匀速直线插补*/
    Array_2 UniformV_CartesianLinePlanning(Array CurJoint, Array EndJoint, double  spacing_n, double period);
    //定步长三点圆弧插补
    Array_2 UniformV_CartesianCirclePlanning(Array StartJoint, Array MidJoint, Array EndJoint, double  spacing_n, double period);
    /*
    * 姿态插补，输入为 起始欧拉角 和 终止欧拉角，输出为返回值 欧拉角序列
    */
    Array_2 EulerAnglePlanning(double startRoll, double startPitch, double startYaw, double endRoll, double endPitch, double endYaw, double size);

    /*
    * 简单点到点，输入关节，以关节插补的形式从现在的点到另一个点，速度规划为梯形规划，最大速度、加速度在函数里面定下不变。
    * 需要设置起点的角度startAngle
    */
    Array_2 Point2PointJointPlanning_PutJoint(
        //起始关节
        Array startAngle,
        // 终点坐标
        Array endAngle,
        // 插补周期
        double period
    );


private:   //用于描述梯形1规划中的各类情况
    static std::vector<Data> Situation1(
        double startPosition,
        double endPosition,
        double maxVelocity,
        double startVelocity,
        double endVelocity,
        double acceleration,
        double period,
        double startAcceleration,
        double endAcceleration);
    static std::vector<Data> Situation2(
        double startPosition,
        double endPosition,
        double maxVelocity,
        double startVelocity,
        double endVelocity,
        double acceleration,
        double period,
        double startAcceleration,
        double endAcceleration);
    static std::vector<Data> Situation3(
        double startPosition,
        double endPosition,
        double maxVelocity,
        double startVelocity,
        double endVelocity,
        double acceleration,
        double period,
        double startAcceleration,
        double endAcceleration);
    static std::vector<Data> Situation4(
        double startPosition,
        double endPosition,
        double maxVelocity,
        double startVelocity,
        double endVelocity,
        double acceleration,
        double period,
        double startAcceleration,
        double endAcceleration);
    static std::vector<Data> Situation5(
        double startPosition,
        double endPosition,
        double maxVelocity,
        double startVelocity,
        double endVelocity,
        double acceleration,
        double period,
        double startAcceleration,
        double endAcceleration);
    static std::vector<Data> Situation6(
        double startPosition,
        double endPosition,
        double maxVelocity,
        double startVelocity,
        double endVelocity,
        double acceleration,
        double period,
        double startAcceleration,
        double endAcceleration);
};
