#include<iostream>
#include "Kinematics.h"
#include "Supervision.h"
#include "MoveFunction.h"
using namespace std;

Array current_position_array(6,0);

Array_2 Moveplanning(int a, Array pos1, Array pos2, Array pos3, double size_n)
{
    DHParam dh;

   MoveFunction MF;

    int FLAG = 0;//全局flag，在kinematics.h中extern声明，所有包含kinematics.h的文件均可使用   1:逆解超出范围  2:关节角超出范围  3:API读取数据失败
    Array_2 Data, PUU; //所有实例的插补结果这里都用Data来存放，所以这行始终不需要管它。

    switch (a) {
    case 1: {
        Array EndJoint = { pos3[0],pos3[1] ,pos3[2] ,pos3[3] ,pos3[4] ,pos3[5] }; //目标关节角度
        MF.Myhrtapi_MoveToTarget_PutJoint(EndJoint, 0.01, Data);
        break;
    }
    case 2: {
        Array StartJoint = { pos1[0],pos1[1] ,pos1[2] ,pos1[3] ,pos1[4] ,pos1[5] };//直线起点关节角度
        Coordinate endCoordinate = { pos3[0],pos3[1] ,pos3[2] ,pos3[3] ,pos3[4] ,pos3[5] };
        MF.Myhrtapi_Moveline(pos1, pos3, 0.01,size_n, Data);
        break;
    }
    case 3: {
        Array StartJoint = { pos1[0],pos1[1] ,pos1[2] ,pos1[3] ,pos1[4] ,pos1[5] };
        Array MidJoint = { pos2[0],pos2[1] ,pos2[2] ,pos2[3] ,pos2[4] ,pos2[5] };
        Array endJoint = { pos3[0],pos3[1] ,pos3[2] ,pos3[3] ,pos3[4] ,pos3[5] };
        MF.Myhrtapi_MoveCircular(StartJoint, MidJoint, endJoint, 0.01, size_n, Data);  //起始点，中间点，末端点对应关节角，时间周期，插补数量，输出一系列关节角度及关节速度Data
        break;
    }
    case 4: {
        MF.Myhrtapi_MoveToZero(Data);
        break;
    }
    default:printf("error:no this case in MovePlanning\n");
    }
    //printfTXT(Data);
    PUU = MF.Myhrtapi_Angle2PUU(Data);
    printPUU_TXT(PUU);
    Array_2  dPUU((PUU.size()-1), vector<double>(6, 0));
    for (int i = 1; i < PUU.size(); i++) {
        for (int j = 0; j < 6; j++) {
            dPUU[i-1][j] = PUU[i][j] - PUU[i-1][j];          
        }  
    }
    return dPUU;

}