#pragma once
#include <array>

typedef struct {
    double theta;  //关节变量
    double d;
    double length;
    double alpha;

    double minTheta; // 关节限位
    double maxTheta;
}param_t;

class  DHParam
{
public:
    DHParam();

    std::array<param_t, 6> param_table;

    double offset_j2;
    double offset_j4;
};

