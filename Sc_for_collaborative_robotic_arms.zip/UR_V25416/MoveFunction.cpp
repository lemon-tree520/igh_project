#include"MoveFunction.h"
#include"TrajectoryPlanning.h"

extern Array current_position_array;
TrajectoryPlanning Tr;
MoveFunction::MoveFunction()
{

}
MoveFunction::~MoveFunction()
{

}

int MoveFunction::GetJointPos(Array& cur_joint_pos, Array PUU) {
	int start = 1;
	cur_joint_pos = Myhrtapi_PUU2Angle(PUU);   //将关节当前的PUU转化为角度
    for(int i=0;i<6;i++)
    {
        if (cur_joint_pos[i] > Tr.trajKine.dh.param_table[i].maxTheta || cur_joint_pos[i] < Tr.trajKine.dh.param_table[i].minTheta)
            start = 0;
    }
	return start;
}
//void MoveFunction::Myhrtapi_read(Array& joint_pos)
//{
//	Array cur_joint_pos(6);
//	int flag;
//	flag = GetJointPos(cur_joint_pos, current_position_array);
//	if (flag == 1) {
//		printf("Ret_joint:");
//		for (int i = 0; i < 6; i++) {
//			joint_pos[i] = cur_joint_pos[i];
//			printf("%f,", cur_joint_pos[i]);
//		}
//		printf("\n");
//	}
//	else {
//		
//		printf("get joint false\n");
//	}
//
//}

void MoveFunction::Myhrtapi_MoveToTarget_PutJoint(Array endJoint, double period, Array_2& DataPoint)
{
    Array curJoint(6);

	GetJointPos(curJoint, current_position_array);
    //curJoint = { 0,0,0,0,0,0 };//当未与机械臂连接时给定当前角度
    DataPoint = Tr.Point2PointJointPlanning_PutJoint(curJoint, endJoint, period);
		
}

void MoveFunction::Myhrtapi_Moveline(Array StartJoint, Array EndJoint, double period, double spacing_n, Array_2& DataPoint)
{
    Array_2 DataPoint1;
    Array_2 DataPoint2;

    Myhrtapi_MoveToTarget_PutJoint(StartJoint, period, DataPoint1);//先运动到直线起始点
    //DataPoint2 = Tr.Eazy_CartesianLinePlanning(StartJoint, endCoordinate, 150, 50, period);   //以梯形速度直线规划运动到终止点
    DataPoint2 = Tr.UniformV_CartesianLinePlanning(StartJoint, EndJoint, spacing_n, period);    //以定步长插补直线规划运动到终止点  
    DataPoint = Myhrtapi_Montage(DataPoint1, DataPoint2);//将两次运动的结果拼接起来
}

void MoveFunction::Myhrtapi_MoveCircular(Array StartJoint, Array Midjoint, Array endJoint, double period, double size, Array_2& DataPoint)
{
    Array_2 DataPoint1;
    Array_2 DataPoint2;
    Myhrtapi_MoveToTarget_PutJoint(StartJoint, period, DataPoint1);//先运动到直线起始点
    DataPoint2 = Tr.UniformV_CartesianCirclePlanning(StartJoint, Midjoint, endJoint, size, period);
    DataPoint = Myhrtapi_Montage(DataPoint1, DataPoint2);//将两次运动的结果拼接起来
}

void MoveFunction::Myhrtapi_MoveToZero(Array_2& DataPoint)
{
    Array curJoint(6);//现在的关节坐标
    Array ZeroPoint = { 0, 0, 0, 0, 0, 0 };
    
    GetJointPos(curJoint, current_position_array);//读取现在的角度
    //curJoint = { 0, 20, 30, 0, 0, 0 };//仿真参考角度，真机测试需注释

    DataPoint = Tr.Point2PointJointPlanning_PutJoint(curJoint, ZeroPoint, 0.01);
}



//数组拼接，只适用于每行12个的数组
Array_2 MoveFunction::Myhrtapi_Montage(Array_2 DataPoint1, Array_2 DataPoint2)
{
    int ROWS1 = DataPoint1.size();
    int ROWS2 = DataPoint2.size();
    Array_2 result((ROWS1 + ROWS2), vector<double>(12, 0));//所有的结果
    for (int i = 0; i < ROWS1; ++i) {
        for (int j = 0; j < 12; ++j) {
            result[i][j] = DataPoint1[i][j];
        }
    }
    for (int i = 0; i < ROWS2; ++i) {
        for (int j = 0; j < 12; ++j) {
            result[i + ROWS1][j] = DataPoint2[i][j];
        }
    }
    return result;
}

















Array_2 MoveFunction::Myhrtapi_Angle2PUU(Array_2 Data)
{
    int RowData = Data.size();
    int PUUbias0 = 23489;
    int PUUbias1 = 69181;
    int PUUbias2 = 112562;
    int PUUbias3 = 81186;
    int PUUbias4 = 82042;
    int PUUbias5 = 39247;
    int retio = 131072 / 360;
    Array_2 PUU(RowData, vector<double>(6, 0));
    for (int i = 0; i < RowData; i++)
    {

        PUU[i][0] = Data[i][0] * retio + PUUbias0;
        PUU[i][1] = Data[i][1] * retio + PUUbias1;
        PUU[i][2] = -(Data[i][2] * retio) + PUUbias2;
        PUU[i][3] = -(Data[i][3] * retio) + PUUbias3;
        PUU[i][4] = -(Data[i][4] * retio) + PUUbias4;
        PUU[i][5] = Data[i][5] * retio + PUUbias5;
    }
    return PUU;
}

Array MoveFunction::Myhrtapi_PUU2Angle(Array PUU)
{
    int PUUbias0 = 23489;
    int PUUbias1 = 69181;
    int PUUbias2 = 112562;
    int PUUbias3 = 81186;
    int PUUbias4 = 82042;
    int PUUbias5 = 39247;

    int retio = 131072 / 360;
    Array Angle(6);
    /*for (int i = 0; i < 6; i++)
    {
        Angle[i] = (PUU[i] - PUUbias) / retio;
    }*/
    Angle[0] = (PUU[0] - PUUbias0) / retio;
    Angle[1] = (PUU[1] - PUUbias1) / retio;
    Angle[2] = -(PUU[2] - PUUbias2) / retio;
    Angle[3] = -(PUU[3] - PUUbias3) / retio;
    Angle[4] = -(PUU[4] - PUUbias4) / retio;
    Angle[5] = (PUU[5] - PUUbias5) / retio;


    return Angle;
}