#pragma once
#include <math.h>
#include <vector>
using namespace std;
#define PI          3.14159265358979
#define sind(x)     sin((x) * PI / 180.0)
#define cosd(x)     cos((x) * PI / 180.0)
#define tand(x)     tan((x) * PI / 180.0)

#define asind(x) 	(asin(x) * 180.0 / PI)
#define acosd(x) 	(acos(x) * 180.0 / PI)
#define atand(x) 	(atan(x) * 180.0 / PI)
#define atan2d(y,x) (atan2(y,x) * 180.0 / PI)

#define DEG2RAD         ( 3.1415926535898/180.0 )
#define RAD2DEG         ( 180.0/3.1415926535898 )

typedef vector<double> Array;
typedef vector<vector<double>> Array_2;//二维double数组
typedef vector<vector< vector<double>>> Array_3;//三维double数组

Array_2 matrix6mul6(Array_2 T1, Array_2 T2);
Array  matrix_mul(Array_2 matrix_a, double matrix_b[4][1], int n);//4X4与4X1矩阵相乘
void matrixMul(Array_2 T1, Array_2 T2, Array_2& T_Mul);
Array_2 inv_matrix(Array_2 T);  //旋转矩阵/齐次变换矩阵转置==求逆
Array_2 matrix_translate(Array_2  matrix); //矩阵转置

/*
 * ZYX
*/
void MatrixToRPY(Array_2 T, Array &xyzrpy);
void RPYToMatrix(Array xyzrpy , Array_2 &T);
/*角度到四元数转换*/
 Array angle2quat(double r1, double r2, double r3);
/*四元数到角度转换*/
 Array quat2angle(double w, double qx, double qy, double qz);
Array solveCenterPointOfCircle(Array Startpoint, Array Midpoint, Array Endpoint);
Array solvePerpendicularVectorOfCircle(Array Startpoint, Array Midpoint, Array Endpoint);




