#pragma once
#include "DHparam.h"
#include "Utils.h"
#include <vector>
#include <map>
#include <string>

#define IS_ZERO(var)    if(var < 0.0000000001 && var > -0.0000000001){ var = 0;}    //限定极小数为0

class Kinematics
{

public:
    Kinematics();
   // Kinematics(DHParam*);
    DHParam dh;
    /*正向运动学解算*/
    void forward_kine(Array joint, Array& cart);
    /*逆运动学解算，原始的8组解*/
    int  inverse_kine(const Array& cart, map<std::string, Array_2>& solutionMap);
    /*选择最优解（同时会对角度进行限制）*/
    Array OptimalJoint(map<std::string, Array_2>& solutionMap, Array Angle_Last);

    void calculate_matrix_A(double theta, double d, double a, double alp, Array_2 &T);
    Array_2 todouble_solution(Array_2 solution);
    bool in_range(double val, param_t* par);


    Array T_jacobian_i(Array_2 T);//求解相对工具坐标系的雅可比矩阵的某一列
    Array_2 T_jacobian(Array_2 T06, Array_2 T16, Array_2 T26, Array_2 T36, Array_2 T46, Array_2 T56);// 相对工具坐标系的雅可比矩阵
    Array_2 jacobian(Array_2 T_jacobian, Array_2 T06); //将相对工具坐标系的雅可比矩阵转换为相对基坐标系的雅可比矩阵  （速度雅可比）
    Array_2 get_jacobian(Array_2 T06, Array_2 T16, Array_2 T26, Array_2 T36, Array_2 T46, Array_2 T56);  //将上面两个函数整合成一个函数


};