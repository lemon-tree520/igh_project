#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <stdbool.h>
#include <signal.h>
#include <sys/mman.h>
#include <time.h>
#include <limits.h>
#include <math.h>
#include <sys/resource.h>
#include <errno.h>
#include <pthread.h>
#include <sched.h>
#include "ecrt.h"
#include "./include/Kinematics.h"
#include"./include/TrajectoryPlanning.h"
#include"./include/Myhrtapi.h"

#define FREQUENCY         1000     //1ms周期
#define CLOCK_TO_USE 1             //clock_nanosleep函数参数，用来指定计时方式，0为CLOCK_REALTIME 可设置的系统范围的实时时钟。1为CLOCK_MONOTONIC 一个不可设置的，单调递增的时钟。

#define NSEC_PER_SEC (1000000000)
//任务周期,单位ns
#define PERIOD_NS (NSEC_PER_SEC / FREQUENCY)

#define DIFF_NS(A, B) (((B).tv_sec - (A).tv_sec) * NSEC_PER_SEC + \
	(B).tv_nsec - (A).tv_nsec)

#define TIMESPEC2NS(T) ((uint64_t) (T).tv_sec * NSEC_PER_SEC + (T).tv_nsec)

#define SLAVE_NUM                            6
#define MOTOR_MODEL_CONTROL_WORD_HALT       0x1 < 8
#define MAX_COLS                               6 

//定义从站的别名，位置，产品号，设备号，由提供的ESI文件获得
#define SLAVE_0_ALIAS                 0
#define SLAVE_0_POSITION              0
#define SLAVE_0_VID_PID               0x0000009a, 0x00030924
#define SLAVE_1_ALIAS                 0
#define SLAVE_1_POSITION              1
#define SLAVE_1_VID_PID               0x0000009a, 0x00030924
#define SLAVE_2_ALIAS                 0
#define SLAVE_2_POSITION              2
#define SLAVE_2_VID_PID               0x0000009a, 0x00030924
#define SLAVE_3_ALIAS                 0
#define SLAVE_3_POSITION              3
#define SLAVE_3_VID_PID               0x0000009a, 0x00030924
#define SLAVE_4_ALIAS                 0
#define SLAVE_4_POSITION              4
#define SLAVE_4_VID_PID               0x0000009a, 0x00030924
#define SLAVE_5_ALIAS                 0
#define SLAVE_5_POSITION              5
#define SLAVE_5_VID_PID               0x0000009a, 0x00030924

#define  SLAVE_1     0
#define  SLAVE_2     1
#define  SLAVE_3     2
#define  SLAVE_4     3
#define  SLAVE_5     4
#define  SLAVE_6     5

//定义从站信息结构体
struct _SlaveInfo {
    uint32_t alias;
    uint32_t position;
    uint32_t vendor;
    uint32_t product_id;
};

//定义从站PDO结构体数组
static struct _SlaveOffset {
    unsigned int ctrl_word;
    unsigned int mode_operation;
    unsigned int target_position;
    unsigned int target_speed;
    unsigned int digital_outputs;
    unsigned int velocity_offset;

    unsigned int status_word;
    signed int current_speed;
    unsigned int current_position;
    unsigned int digital_inputs;
} slave_offset[SLAVE_NUM];

//定义与从站配置相关变量的结构体
struct _SlaveConfig {
    ec_slave_config_t       *sc;
    ec_slave_config_state_t sc_state;
};

//定义与域配置相关变量的结构体
struct _Domain {
    ec_domain_t         *domain;
    ec_domain_state_t   domain_state;
    uint8_t             *domain_pd;
};

//填充ec_pdo_entry_reg_t类型的结构体，将定义的变量名与从站PDO对应起来
const static ec_pdo_entry_reg_t domain_regs[] = {
    /* Slave 0 */
    {SLAVE_0_ALIAS, SLAVE_0_POSITION, SLAVE_0_VID_PID, 0x607A, 0, &slave_offset[0].target_position},
    {SLAVE_0_ALIAS, SLAVE_0_POSITION, SLAVE_0_VID_PID, 0x60FE, 1, &slave_offset[0].digital_outputs},
    {SLAVE_0_ALIAS, SLAVE_0_POSITION, SLAVE_0_VID_PID, 0x6040, 0, &slave_offset[0].ctrl_word},
    {SLAVE_0_ALIAS, SLAVE_0_POSITION, SLAVE_0_VID_PID, 0x6064, 0, &slave_offset[0].current_position},
    {SLAVE_0_ALIAS, SLAVE_0_POSITION, SLAVE_0_VID_PID, 0x60FD, 0, &slave_offset[0].digital_inputs},
    {SLAVE_0_ALIAS, SLAVE_0_POSITION, SLAVE_0_VID_PID, 0x6041, 0, &slave_offset[0].status_word},
    /* Slave 1 */
    {SLAVE_1_ALIAS, SLAVE_1_POSITION, SLAVE_1_VID_PID, 0x607A, 0, &slave_offset[1].target_position},
    {SLAVE_1_ALIAS, SLAVE_1_POSITION, SLAVE_1_VID_PID, 0x60FE, 1, &slave_offset[1].digital_outputs},
    {SLAVE_1_ALIAS, SLAVE_1_POSITION, SLAVE_1_VID_PID, 0x6040, 0, &slave_offset[1].ctrl_word},
    {SLAVE_1_ALIAS, SLAVE_1_POSITION, SLAVE_1_VID_PID, 0x6064, 0, &slave_offset[1].current_position},
    {SLAVE_1_ALIAS, SLAVE_1_POSITION, SLAVE_1_VID_PID, 0x60FD, 0, &slave_offset[1].digital_inputs},
    {SLAVE_1_ALIAS, SLAVE_1_POSITION, SLAVE_1_VID_PID, 0x6041, 0, &slave_offset[1].status_word},
    /* Slave 2 */
    {SLAVE_2_ALIAS, SLAVE_2_POSITION, SLAVE_2_VID_PID, 0x607A, 0, &slave_offset[2].target_position},
    {SLAVE_2_ALIAS, SLAVE_2_POSITION, SLAVE_2_VID_PID, 0x60FE, 1, &slave_offset[2].digital_outputs},
    {SLAVE_2_ALIAS, SLAVE_2_POSITION, SLAVE_2_VID_PID, 0x6040, 0, &slave_offset[2].ctrl_word},
    {SLAVE_2_ALIAS, SLAVE_2_POSITION, SLAVE_2_VID_PID, 0x6064, 0, &slave_offset[2].current_position},
    {SLAVE_2_ALIAS, SLAVE_2_POSITION, SLAVE_2_VID_PID, 0x60FD, 0, &slave_offset[2].digital_inputs},
    {SLAVE_2_ALIAS, SLAVE_2_POSITION, SLAVE_2_VID_PID, 0x6041, 0, &slave_offset[2].status_word},
    /* Slave 3 */
    {SLAVE_3_ALIAS, SLAVE_3_POSITION, SLAVE_3_VID_PID, 0x607A, 0, &slave_offset[3].target_position},
    {SLAVE_3_ALIAS, SLAVE_3_POSITION, SLAVE_3_VID_PID, 0x60FE, 1, &slave_offset[3].digital_outputs},
    {SLAVE_3_ALIAS, SLAVE_3_POSITION, SLAVE_3_VID_PID, 0x6040, 0, &slave_offset[3].ctrl_word},
    {SLAVE_3_ALIAS, SLAVE_3_POSITION, SLAVE_3_VID_PID, 0x6064, 0, &slave_offset[3].current_position},
    {SLAVE_3_ALIAS, SLAVE_3_POSITION, SLAVE_3_VID_PID, 0x60FD, 0, &slave_offset[3].digital_inputs},
    {SLAVE_3_ALIAS, SLAVE_3_POSITION, SLAVE_3_VID_PID, 0x6041, 0, &slave_offset[3].status_word},
    /* Slave 4 */
    {SLAVE_4_ALIAS, SLAVE_4_POSITION, SLAVE_4_VID_PID, 0x607A, 0, &slave_offset[4].target_position},
    {SLAVE_4_ALIAS, SLAVE_4_POSITION, SLAVE_4_VID_PID, 0x60FE, 1, &slave_offset[4].digital_outputs},
    {SLAVE_4_ALIAS, SLAVE_4_POSITION, SLAVE_4_VID_PID, 0x6040, 0, &slave_offset[4].ctrl_word},
    {SLAVE_4_ALIAS, SLAVE_4_POSITION, SLAVE_4_VID_PID, 0x6064, 0, &slave_offset[4].current_position},
    {SLAVE_4_ALIAS, SLAVE_4_POSITION, SLAVE_4_VID_PID, 0x60FD, 0, &slave_offset[4].digital_inputs}, 
    {SLAVE_4_ALIAS, SLAVE_4_POSITION, SLAVE_4_VID_PID, 0x6041, 0, &slave_offset[4].status_word},
    /* Slave 5 */
    {SLAVE_5_ALIAS, SLAVE_5_POSITION, SLAVE_5_VID_PID, 0x607A, 0, &slave_offset[5].target_position},
    {SLAVE_5_ALIAS, SLAVE_5_POSITION, SLAVE_5_VID_PID, 0x60FE, 1, &slave_offset[5].digital_outputs},
    {SLAVE_5_ALIAS, SLAVE_5_POSITION, SLAVE_5_VID_PID, 0x6040, 0, &slave_offset[5].ctrl_word},
    {SLAVE_5_ALIAS, SLAVE_5_POSITION, SLAVE_5_VID_PID, 0x6064, 0, &slave_offset[5].current_position},
    {SLAVE_5_ALIAS, SLAVE_5_POSITION, SLAVE_5_VID_PID, 0x60FD, 0, &slave_offset[5].digital_inputs},
    {SLAVE_5_ALIAS, SLAVE_5_POSITION, SLAVE_5_VID_PID, 0x6041, 0, &slave_offset[5].status_word},
    {}
};

//填充ec_pdo_entry_info_t类型的结构体，列举使用的PDO信息，将PDO按照发送和接收排列。方便分组
ec_pdo_entry_info_t slave_pdo_entries[] = {
    {0x607A, 0x00, 32},
    {0x60FE, 0x01, 32},
    {0x6040, 0x00, 16},
    {0x6064, 0x00, 32},
    {0x60FD, 0x00, 32},
    {0x6041, 0x00, 16},
};

//分组PDO，将PDO分为RXPDO和TXPDO
 ec_pdo_info_t slave_pdos[] = {
    {0x1600, 3, slave_pdo_entries + 0},
    {0x1A00, 3, slave_pdo_entries + 3},
};

//管理PDO，将TXPDO和RXPDO放入同步管理器中管理
ec_sync_info_t slave_syncs[] = {
    {0, EC_DIR_OUTPUT, 0, NULL, EC_WD_DISABLE},
    {1, EC_DIR_INPUT, 0, NULL, EC_WD_DISABLE},
    {2, EC_DIR_OUTPUT, 1, slave_pdos + 0, EC_WD_ENABLE},
    {3, EC_DIR_INPUT, 1, slave_pdos + 1, EC_WD_DISABLE},
    {0xff}
};

//填充从站信息结构体
struct _SlaveInfo slave_info[] = {
    {SLAVE_0_ALIAS, SLAVE_0_POSITION, SLAVE_0_VID_PID},
    {SLAVE_1_ALIAS, SLAVE_1_POSITION, SLAVE_1_VID_PID},
    {SLAVE_2_ALIAS, SLAVE_2_POSITION, SLAVE_2_VID_PID},
    {SLAVE_3_ALIAS, SLAVE_3_POSITION, SLAVE_3_VID_PID},
    {SLAVE_4_ALIAS, SLAVE_4_POSITION, SLAVE_4_VID_PID},
    {SLAVE_5_ALIAS, SLAVE_5_POSITION, SLAVE_5_VID_PID},
};

//线程传参
typedef struct {
    struct _SlaveConfig *slave_config;
    struct _Domain domain;
} ThreadArgs;

static ec_master_t          *master = NULL;    //定义一个主站指针
static ec_master_state_t    master_state = {}; //定义主站状态结构体
struct _Domain domain;                         //实例一个域结构体
const struct timespec cycletime = {0, PERIOD_NS};

int a = 4;                                      //模式设置，其中1为MOVE_J(只需要设置终点位置)，2为MOVE_L(只需要设置起始位置，终点位置)，3为MOVE_C（需要设置起始位置，中间位置，终点位置），4为回零操作
double size_n = 10000;                          //直线圆弧的插补点数（MOVE_L和MOVE_C使用）
Array_2 d_PUU;                                  //定义一个二维数组存放下发的控制数据
Array current_position_array(6);                //定义一个数组存放六个关节的当前位置
Array pos1 = {0,18,82.8,-10.8,-93.6,0};//{-25.2,43.2,50.4,0,-93.6,0};//{ 0,32.4,43.2,0,-93.6,0 };           //起始位置
Array pos2 = {-14.4,28.8,68.4,-7.2,-90,0};//{ 50,-30,-90,18,90,0 };   //50,-30,-90,18,90,0                  //中间位置
Array pos3 = {-27.2,21.6,90,-21.6,-90,0};//{-25.2,10.8,126,-25.2,-93.6,0};//{-25.2,43.2,50.4,0,-93.6,0};    //终点位置

//检查域状态函数
void check_domain_state(struct _Domain *domain)
{
    ec_domain_state_t ds;
    ecrt_domain_state(domain->domain, &ds);

    if (ds.working_counter != domain->domain_state.working_counter) {
        printf("--> check_domain_state: Domain: WC %u.\n", ds.working_counter);
    }

    if (ds.wc_state != domain->domain_state.wc_state) {
        printf("--> check_domain_state: Domain: State %u.\n", ds.wc_state);
    }

    domain->domain_state = ds;
}
//定时函数
struct timespec timespec_add(struct timespec time1, struct timespec time2)
{
	struct timespec result;

	if ((time1.tv_nsec + time2.tv_nsec) >= NSEC_PER_SEC) {
		result.tv_sec = time1.tv_sec + time2.tv_sec + 1;
		result.tv_nsec = time1.tv_nsec + time2.tv_nsec - NSEC_PER_SEC;
	} else {
		result.tv_sec = time1.tv_sec + time2.tv_sec;
		result.tv_nsec = time1.tv_nsec + time2.tv_nsec;
	}

	return result;
}
//检查主站状态函数
void check_master_state()
{
    ec_master_state_t ms;
    ecrt_master_state(master, &ms);

	if (ms.slaves_responding != master_state.slaves_responding) {
        printf("--> check_master_state: %u slave(s).\n", ms.slaves_responding);
    }

    if (ms.al_states != master_state.al_states) {
        printf("--> check_master_state: AL states: 0x%02X.\n", ms.al_states);
    }

    if (ms.link_up != master_state.link_up) {
        printf("--> check_master_state: Link is %s.\n", ms.link_up ? "up" : "down");
    }

    master_state = ms;
}
//检查从站状态函数
void check_slave_config_state(struct _SlaveConfig *slave_config)
{
    ec_slave_config_state_t s;
    int i;
    for (i = 0; i < SLAVE_NUM; i++) {
    memset(&s, 0, sizeof(s));
    ecrt_slave_config_state(slave_config[i].sc, &s);
    if (s.al_state != slave_config[i].sc_state.al_state) {
        printf("--> check_slave_config_state: slave[%d]: State 0x%02X.\n", i,s.al_state);
    }

    if (s.online != slave_config[i].sc_state.online) {
        printf("--> check_slave_config_state: slave[%d]: %s.\n", i, s.online ? "online" : "offline");
    }
    if (s.operational != slave_config[i].sc_state.operational) {
        printf("--> check_slave_config_state: slave[%d]: %soperational.\n", i, s.operational ? "" : "Not ");
    }
        slave_config[i].sc_state = s;
    }
}
//使能函数
void switch_status(struct _Domain *domain,int i)
{
    static uint16_t command[6] = {0x004F,0x004F,0x004F,0x004F,0x004F,0X004F};
    static uint16_t status;
    status = EC_READ_U16(domain->domain_pd + slave_offset[i].status_word);
    if(status == 0x218)
    {
        EC_WRITE_U16(domain->domain_pd + slave_offset[i].ctrl_word, 0x80);      //控制字写入0x08，清除错误状态
    }
    if ((status & command[i]) == 0x0040) 
    {
        EC_WRITE_U16(domain->domain_pd + slave_offset[i].ctrl_word, 0x0006);    //控制字写入0x06,进入下一状态
        command[i] = 0x006F;
    }
    else if ((status & command[i]) == 0x0021) 
    {
        EC_WRITE_U16(domain->domain_pd + slave_offset[i].ctrl_word, 0x0007);    //控制字写入0x07,进入下一状态
        command[i] = 0x006F;
    }
    else if ((status & command[i]) == 0x0023) 
    {
        EC_WRITE_U16(domain->domain_pd + slave_offset[i].ctrl_word, 0x000f);    //控制字写入0x0f，完成使能
        command[i] = 0x006F;
    }
}
//电机停止函数
void  stop_servo()
{
    int i;
    ecrt_master_receive(master);
    ecrt_domain_process(domain.domain);
    for (i = 0; i < SLAVE_NUM; i++) {
        EC_WRITE_U16(domain.domain_pd + slave_offset[i].ctrl_word, MOTOR_MODEL_CONTROL_WORD_HALT);  //控制字bit8置1，电机停止
    }
    ecrt_domain_queue(domain.domain);
    ecrt_master_send(master);
}
//信号量服务函数，触发电机停止和主站释放
void signalHandler(int signum)
{
    printf("\r\n end running,servo stop and release master! \r\n");
    stop_servo();
    ecrt_release_master(master);
    exit(0);
}

//控制任务线程
void* rt_cyclic_task(void* arg)
{
    ThreadArgs* args = (ThreadArgs*)arg;
    struct _SlaveConfig *slave_config = args->slave_config;  //接收线程参数
    struct _Domain *domain = &(args->domain);
    struct timespec wakeupTime;
    static int i,j,delay = 0;
    int flag = 1;                                            //运算结束标志位
    int status[6] = {};
    static double running_time,sum_time = 0; 
    clock_gettime(CLOCK_TO_USE, &wakeupTime);               //获取系统时间
    while (1) 
    {
		wakeupTime = timespec_add(wakeupTime, cycletime);   //设置定时时间
        clock_nanosleep(CLOCK_TO_USE,1, &wakeupTime, NULL); //完成定时设置
        ecrt_master_application_time(master, TIMESPEC2NS(wakeupTime));  //主站获取应用程序时间

        check_domain_state(domain);                         //监测域状态
        check_master_state();                               //监测主站状态
        check_slave_config_state(slave_config);             //监测从站状态

        ecrt_master_receive(master);                        //主站接受从站返回帧
        ecrt_domain_process(domain->domain);                //主站获取过程数据域
        
        switch_status(domain,SLAVE_1);                      //从站使能
        switch_status(domain,SLAVE_2);                      
        switch_status(domain,SLAVE_3);
        switch_status(domain,SLAVE_4);
        switch_status(domain,SLAVE_5);
        switch_status(domain,SLAVE_6);
        
        //打印从站状态（实际操作中尽量减少printf函数的调用，影响实时性）
        for(int m=0;m<6;m++){
            status[m]=EC_READ_U16(domain->domain_pd + slave_offset[m].status_word);
            printf("status[%d]=%#x\r\n",m,EC_READ_U16(domain->domain_pd + slave_offset[m].status_word));
        }
        
        //使能后获取六轴的当前位置，存放在current_position_array数组中
        for(int m=0;m<6;m++){
            if(EC_READ_U16(domain->domain_pd + slave_offset[m].status_word)!=0x1237){
                EC_WRITE_U32(domain->domain_pd + slave_offset[m].target_position,EC_READ_U32(domain->domain_pd + slave_offset[m].current_position));
            }else{
                current_position_array[m] = (double)EC_READ_U32(domain->domain_pd + slave_offset[m].current_position);
            }
        }

        //判断最后一个轴是否使能，如果使能则代表六个轴均使能，进入Moveplanning函数做运算，运算后的控制数据存放在d_PUU数组中
        if(current_position_array[5] && flag != 0){
            d_PUU = Moveplanning(a,pos1,pos2,pos3,size_n,&flag);
        }

        //30s后，六轴均使能后开始传输控制数据
        if(delay>=30000){
            if(status[0]==0x1237 && status[1]==0x1237 && status[2]==0x1237 && status[3]==0x1237 && status[4]==0x1237 && status[5]==0x1237){
                running_time = (float)i*FREQUENCY/1000000;
                for(int k=0;k<6;k++){
                    if(d_PUU[i][j+k]>=0.1 || d_PUU[i][j+k]<=-0.1){
                        EC_WRITE_U32(domain->domain_pd + slave_offset[SLAVE_1+k].target_position,EC_READ_U32(domain->domain_pd + slave_offset[SLAVE_1+k].current_position)+(int)13*d_PUU[i][j+k]);
                    }
                }
            i++;
            }
        }
        delay++;
        sum_time = (float)delay*FREQUENCY/1000000;
        ecrt_master_sync_reference_clock(master);  //参考时钟将同步于最后一次调用 ecrt_master_application_time() 提供的应用时间
        ecrt_master_sync_slave_clocks(master);     //将 DC clock drift compensation 数据报排队以进行发送。所有从时钟都与参考同步
        ecrt_domain_queue(domain->domain);
        ecrt_master_send(master);
    }
}

int main(int argc, char **argv)
{
    int status = 0, ret = -1, i = 0;
    pthread_t rt_pthread;
    pthread_t watch_pthread;
    pthread_attr_t attr;
    struct sched_param param;
    struct _SlaveConfig slave_config[SLAVE_NUM];
    //设置线程属性和优先级
    param.sched_priority = 99;
    pthread_attr_init(&attr);
    pthread_attr_setstacksize(&attr,PTHREAD_STACK_MIN);
    pthread_attr_setschedpolicy(&attr, SCHED_FIFO);
    pthread_attr_setschedparam(&attr, &param);
    pthread_attr_setinheritsched(&attr,PTHREAD_EXPLICIT_SCHED);
    //锁存，防止内存交换
    if(mlockall(MCL_CURRENT|MCL_FUTURE) == -1){
        printf("mlockall failed!\r\n");
        exit(-2);
    }
    //申请主站设备，返回操作内核层的主站指针
    master = ecrt_request_master(0);
    if (!master) {
        printf("--> main: Request master failed.\n");
        return -1;
    }
    printf("--> main: Request master success.\n");
    check_master_state();
    memset(&slave_config, 0, sizeof(slave_config));
    memset(&domain, 0, sizeof(domain));
    //创建域，返回域指针
    domain.domain = ecrt_master_create_domain(master);
    if (!domain.domain) {
        status = -1;
        printf("--> main: Create domain failed.\n");
        return -1;
    }
    printf("--> main: Create domain success.\n");
    //配置从站
    for (i = 0; i < SLAVE_NUM; i++) {
        slave_config[i].sc = ecrt_master_slave_config(master, slave_info[i].alias,slave_info[i].position, slave_info[i].vendor,slave_info[i].product_id);
        if (!slave_config[i].sc) {
            status = -1;
            printf("--> main: Get slave configuration failed.\n");
            return -1;
        }
    }
    printf("--> main: Get slave configuration success.\n");
    //配置SDO,设置操作模式
    for (i = 0; i < SLAVE_NUM; i++) {
        ecrt_slave_config_sdo8(slave_config[i].sc,0x6060,0,0x08);
    }
    printf("--> main: Configuration SDO success.\n");
    //配置PDO
    for (i = 0; i < SLAVE_NUM; i++) {
        ret = ecrt_slave_config_pdos(slave_config[i].sc, EC_END, slave_syncs);
        if (ret != 0) {
            status = -1;
            printf("--> main: Configuration PDO failed.\n");
            return -1;
        }
    }
    printf("--> main: Configuration PDO success.\n");
   //注册PDO目录
    ret = ecrt_domain_reg_pdo_entry_list(domain.domain, domain_regs);
    if (ret != 0) {
        status = -1;
        printf("--> main: Failed to register bunch of PDO entries for domain.\n");
        return -1;
    }
    printf("--> main: success to register bunch of PDO entries for domain.\n");
    //配置使能从站DC时钟功能
    for (i = 0; i < SLAVE_NUM; i++) {
        ecrt_slave_config_dc(slave_config[i].sc,0x0300,5000000, 5000000, 0, 0);
    }
    printf("--> main: Configuration DC success.\n");
    //设定参考时钟
    ret = ecrt_master_select_reference_clock(master, NULL);   //选择参考时钟，这里选择第一个具有DC功能的从站提供参考时钟
    if (ret < 0) {
        printf( "  Failed to select reference clock\n",
                strerror(-ret));
        return ret;
    }
    //激活主站
    ret = ecrt_master_activate(master);
    if (ret < 0) {
        status = -1;
        printf("--> main: Activate master failed.\n");
        return -1;
    }
    printf("--> main: Activate master success.\n");
    //获取域中的过程数据
    domain.domain_pd = ecrt_domain_data(domain.domain);
    if (!domain.domain_pd) {
        status = -1;
        printf("--> main: Get pointer to the process data memory failed.\n");
        return -1;
    }
    printf("--> main: Get pointer to the process data memory success........\n");
    //信号量函数，用于监控电机的停止
    signal(SIGINT,signalHandler);
    //构建线程
    ThreadArgs arg = {slave_config,domain};
    if (pthread_create(&rt_pthread, &attr, rt_cyclic_task, (void*)&arg) != 0) {
        perror("Failed to create rt_cyclic_task thread");
        exit(EXIT_FAILURE);
    }
    pthread_join(rt_pthread, NULL);
	return status;
}
