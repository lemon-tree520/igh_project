#include "Utils.h"
#include <cmath>

Array_2 matrix6mul6(Array_2 T1, Array_2 T2)
{
    Array_2 T_result(6, vector<double>(6,0));

    int K = sizeof(T2) / sizeof(T2[0]);  //列数
    for (int i = 0; i < T1.size(); i++)
    {
        double sum = 0;
        for (int j = 0; j < T1.size(); j++)
        {
            for (int k = 0; k < K; k++)
            {
                sum += T1[i][j] * T2[j][k];
                T_result[i][k] = sum;
            }
        }
    }
    return T_result;
}
Array  matrix_mul(Array_2 matrix_a, double matrix_b[4][1], int n)  //4X4与4X1矩阵相乘
{
    Array matrix_result(4);
    int i, j, k;
    double sum;
    // double matrix_tmp[MATRIX_N][MATRIX_N] = { {0},{0},{0},{0} };

     //嵌套循环计算结果矩阵的每个元素
    for (i = 0; i < 4; i++)
    {
        sum = 0;
        for (j = 0; j < 4; j++)
        {
            //按照矩阵乘法的规则计算结果矩阵的i*j元素

            for (k = 0; k < n; k++)
                sum += matrix_a[i][j] * matrix_b[j][k];
            matrix_result[i] = sum;
        };
    };

    return matrix_result;
}
void matrixMul(Array_2 T1, Array_2 T2, Array_2& T_Mul) {
    //用于求解两矩阵相乘，结果输出为：matrix_tmp[4][4]
    int i, j, k;
    double sum;

    //嵌套循环计算结果矩阵的每个元素
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 4; j++)
        {
            //按照矩阵乘法的规则计算结果矩阵的i*j元素
            sum = 0;
            for (k = 0; k < 4; k++)
                sum += T1[i][k] * T2[k][j];
            T_Mul[i][j] = sum;
        };
    };

}
Array_2 inv_matrix(Array_2 T)  //旋转矩阵/齐次变换矩阵转置==求逆
{
    Array_2 inv_R(3, vector<double>(3));
    Array_2 inv_T(4, vector<double>(4));
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            inv_R[j][i] = T[i][j];
        }
    }
    if (T.size() == 3)
    {
        return  inv_R;
    }
    if (T.size() == 4)
    {
        Array_2 T_4(4, vector<double>(1));
        Array_2 P(3, vector<double>(1)); P[0][0] = -T[0][3]; P[1][0] = -T[1][3]; P[2][0] = -T[2][3];
        T_4 = matrix6mul6(inv_R, P);
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                inv_T[i][j] = inv_R[i][j];
            }
        }
        for (int i = 0; i < 3; i++)
        {
            inv_T[i][3] = T_4[i][0];
        }
        inv_T[3] = { 0,0,0,1 };
    }
    return inv_T;
}
Array_2 matrix_translate(Array_2  matrix)  //矩阵转置
{
    int row = sizeof(matrix)/ sizeof(matrix[0]);
    int column = sizeof(matrix[0]) / sizeof(matrix[0][0]);
    Array_2 T(column, vector<double>(row, 0));

    int i, j;

    for (i = 0; i < row; i++)
    {
        for (j = 0; j < column; j++)
        {
            T[j][i] = matrix[i][j];
        }
    }
    return T;
}

void MatrixToRPY(Array_2 T, Array &xyzrpy)    //ZYX旋转矩阵转RPY角
{
   
    double A, B, C;
    
    if (abs(abs(T[0][2]) - 1) < 1e-6)   //旋转矩阵第三行第一列值为+/-1
    {
        if (T[0][2] > 1e-6)    //值为1，sinB==-1, 只能计算a+c
        {
            B = -PI / 2;
            A = 0;
            C = atan2(-T[0][1], -T[0][2]);
        }
        if (T[0][2] < -1e-6)    //值为1，sinB==1,只能计算a-c
        {
            B = PI / 2;
            A = 0;
            C = atan2(-T[0][1], T[0][2]);
        }
    }
    else
    {
        A = atan2(T[2][1], T[2][2]);
        C = atan2(T[1][0], T[0][0]);


        if (abs(cos(C)) > abs(sin(C)))
            B = atan2(-T[2][0], T[0][0] / cos(C));
        else
            B = atan2(-T[0][0], T[1][0] / sin(C));
    }
    xyzrpy[3] = A; xyzrpy[4] = B; xyzrpy[5] = C;
}

void RPYToMatrix(Array xyzrpy,Array_2 &T ) //RPY转旋转矩阵
{
    double A = xyzrpy[3];
    double B = xyzrpy[4];
    double C = xyzrpy[5];
    /*生成姿态阵*/
    T[0][0] = cosd(C) * cosd(B);
    T[0][1] = cosd(C) * sind(B) * sind(A) - sind(C) * cosd(A);
    T[0][2] = cosd(C) * sind(B) * cosd(A) + sind(C) * sind(A);
    T[1][0] = sind(C) * cosd(B);
    T[1][1] = sind(C) * sind(B) * sind(A) + cosd(C) * cosd(A);
    T[1][2] = sind(C) * sind(B) * cosd(A) - cosd(C) * sind(A);
    T[2][0] = -sind(B);
    T[2][1] = cosd(B) * sind(A);
    T[2][2] = cosd(B) * cosd(A);

    T[0][3] = xyzrpy[0];           //将位置补入变换矩阵 
    T[1][3] = xyzrpy[1];
    T[2][3] = xyzrpy[2];
    T[3][0] = 0;                //  将旋转矩阵第四行补全
    T[3][1] = 0;
    T[3][2] = 0;
    T[3][3] = 1;
}

Array angle2quat(double Angleroll, double AnglePitch, double AngleYaw)//输入为xyz，输出为wxyz
{
    Angleroll *= (PI / 180.0); AnglePitch *= (PI / 180.0); AngleYaw *= (PI / 180.0);


    Array solution(4, 0.0);
    Array angles = { Angleroll, AnglePitch, AngleYaw };
    Array cang(3, 0.0);
    Array sang(3, 0.0);

    for (size_t j = 0; j < 3; ++j) {
        cang[j] = cos(angles[j] / 2.0);
        sang[j] = sin(angles[j] / 2.0);
    }

    solution[0] = cang[0] * cang[1] * cang[2] - sang[0] * sang[1] * sang[2];
    solution[1] = cang[0] * sang[1] * sang[2] + sang[0] * cang[1] * cang[2];
    solution[2] = cang[0] * sang[1] * cang[2] - sang[0] * cang[1] * sang[2];
    solution[3] = cang[0] * cang[1] * sang[2] + sang[0] * sang[1] * cang[2];
    return solution;
}

Array quat2angle(double w, double qx, double qy, double qz) //输入为wxyz，输出为xyz
{
    Array solution = { w,qx ,qy ,qz };
    auto quatnormalize = [](const Array& qin) -> Array {
        return qin;
        };

    Array qin = quatnormalize(solution);

    double r1 = atan2(-2.0 * (qin[2] * qin[3] - qin[0] * qin[1]),
        qin[0] * qin[0] - qin[1] * qin[1] - qin[2] * qin[2] + qin[3] * qin[3]) * (180.0 / PI);

    double r2 = asin(2.0 * (qin[1] * qin[3] + qin[0] * qin[2])) * (180.0 / PI);

    double r3 = atan2(-2.0 * (qin[1] * qin[2] - qin[0] * qin[3]),
        qin[0] * qin[0] + qin[1] * qin[1] - qin[2] * qin[2] - qin[3] * qin[3]) * (180.0 / PI);

    return { r1, r2, r3 };
}

//求空间三点构成圆弧圆心
Array solveCenterPointOfCircle(Array Startpoint, Array Midpoint, Array Endpoint)
{
    Array centerpoint(3);
    double a1, b1, c1, d1;
    double a2, b2, c2, d2;
    double a3, b3, c3, d3;

    double x1 = Startpoint[0], y1 = Startpoint[1], z1 = Startpoint[2];
    double x2 = Midpoint[0], y2 = Midpoint[1], z2 = Midpoint[2];
    double x3 = Endpoint[0], y3 = Endpoint[1], z3 = Endpoint[2];

    a1 = (y1 * z2 - y2 * z1 - y1 * z3 + y3 * z1 + y2 * z3 - y3 * z2);
    b1 = -(x1 * z2 - x2 * z1 - x1 * z3 + x3 * z1 + x2 * z3 - x3 * z2);
    c1 = (x1 * y2 - x2 * y1 - x1 * y3 + x3 * y1 + x2 * y3 - x3 * y2);
    d1 = -(x1 * y2 * z3 - x1 * y3 * z2 - x2 * y1 * z3 + x2 * y3 * z1 + x3 * y1 * z2 - x3 * y2 * z1);

    a2 = 2 * (x2 - x1);
    b2 = 2 * (y2 - y1);
    c2 = 2 * (z2 - z1);
    d2 = x1 * x1 + y1 * y1 + z1 * z1 - x2 * x2 - y2 * y2 - z2 * z2;

    a3 = 2 * (x3 - x1);
    b3 = 2 * (y3 - y1);
    c3 = 2 * (z3 - z1);
    d3 = x1 * x1 + y1 * y1 + z1 * z1 - x3 * x3 - y3 * y3 - z3 * z3;

    centerpoint[0] = -(b1 * c2 * d3 - b1 * c3 * d2 - b2 * c1 * d3 + b2 * c3 * d1 + b3 * c1 * d2 - b3 * c2 * d1)
        / (a1 * b2 * c3 - a1 * b3 * c2 - a2 * b1 * c3 + a2 * b3 * c1 + a3 * b1 * c2 - a3 * b2 * c1);
    centerpoint[1] = (a1 * c2 * d3 - a1 * c3 * d2 - a2 * c1 * d3 + a2 * c3 * d1 + a3 * c1 * d2 - a3 * c2 * d1)
        / (a1 * b2 * c3 - a1 * b3 * c2 - a2 * b1 * c3 + a2 * b3 * c1 + a3 * b1 * c2 - a3 * b2 * c1);
    centerpoint[2] = -(a1 * b2 * d3 - a1 * b3 * d2 - a2 * b1 * d3 + a2 * b3 * d1 + a3 * b1 * d2 - a3 * b2 * d1)
        / (a1 * b2 * c3 - a1 * b3 * c2 - a2 * b1 * c3 + a2 * b3 * c1 + a3 * b1 * c2 - a3 * b2 * c1);

    return centerpoint;
}
//求三点构成平面的法向量
Array solvePerpendicularVectorOfCircle(Array Startpoint, Array Midpoint, Array Endpoint)
{
    Array OP(3);
    double x1 = Startpoint[0];  double y1 = Startpoint[1]; double z1 = Startpoint[2];
    double x2 = Midpoint[0];	   double y2 = Midpoint[1];	 double z2 = Midpoint[2];
    double x3 = Endpoint[0];	   double y3 = Endpoint[1];	 double z3 = Endpoint[2];
    OP[0] = (y2 - y1) * (z3 - z1) - (z2 - z1) * (y3 - y1);
    OP[1] = (z2 - z1) * (x3 - x1) - (x2 - x1) * (z3 - z1);
    OP[2] = (x2 - x1) * (y3 - y1) - (y2 - y1) * (x3 - x1);
    return OP;
}