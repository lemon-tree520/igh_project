#include "Kinematics.h"
#include "Utils.h"

 Kinematics::Kinematics() {

 }
// Kinematics::Kinematics(DHParam*) { }


 /*
 //标准型DH参数生成旋转矩阵
 */
 void Kinematics::calculate_matrix_A(double theta, double d, double a, double alp, Array_2& T) {
     //根据DH参数生成T矩阵
     double c_theta, s_theta, c_alp, s_alp;
     c_theta = cos(theta);            IS_ZERO(c_theta);
     s_theta = sin(theta);            IS_ZERO(s_theta);
     c_alp = cos(alp);                IS_ZERO(c_alp);
     s_alp = sin(alp);                IS_ZERO(s_alp);

     T[0][0] = c_theta;
     T[0][1] = -s_theta * c_alp;
     T[0][2] = s_theta * s_alp;
     T[0][3] = a * c_theta;

     T[1][0] = s_theta;
     T[1][1] = c_theta * c_alp;
     T[1][2] = -c_theta * s_alp;
     T[1][3] = a * s_theta;

     T[2][0] = 0;
     T[2][1] = s_alp;
     T[2][2] = c_alp;
     T[2][3] = d;

     T[3][0] = 0;
     T[3][1] = 0;
     T[3][2] = 0;
     T[3][3] = 1;

 }
 


 /*
* @brief: 正解算
* @param: joint：一维数组，存储六个关节角度,为角度制 cart：一维数组，存储6个位姿参数
* @output：空
*/
 void Kinematics::forward_kine(Array joint, Array& cart)
 {
     //Array joint(6);
     Array_2 T01(4, vector<double>(4, 0)), T12(4, vector<double>(4, 0)), T23(4, vector<double>(4, 0)), T34(4, vector<double>(4, 0)), T45(4, vector<double>(4, 0)), T56(4, vector<double>(4, 0));
     Array_2 T02(4, vector<double>(4, 0)), T03(4, vector<double>(4, 0)), T04(4, vector<double>(4, 0)), T05(4, vector<double>(4, 0));
     Array_2 T06(4, vector<double>(4, 0));
     for (int i = 0; i < 6; i++)
     {

         joint[i] = joint[i] * PI / 180;
     }
     joint[1] += dh.offset_j2;
     joint[3] += dh.offset_j4;

     calculate_matrix_A(joint[0], dh.param_table[0].d, dh.param_table[0].length, dh.param_table[0].alpha, T01);
     calculate_matrix_A(joint[1], dh.param_table[1].d, dh.param_table[1].length, dh.param_table[1].alpha, T12);
     calculate_matrix_A(joint[2], dh.param_table[2].d, dh.param_table[2].length, dh.param_table[2].alpha, T23);
     calculate_matrix_A(joint[3], dh.param_table[3].d, dh.param_table[3].length, dh.param_table[3].alpha, T34);
     calculate_matrix_A(joint[4], dh.param_table[4].d, dh.param_table[4].length, dh.param_table[4].alpha, T45);
     calculate_matrix_A(joint[5], dh.param_table[5].d, dh.param_table[5].length, dh.param_table[5].alpha, T56);



     matrixMul(T01, T12, T02); ;
     matrixMul(T02, T23, T03);
     matrixMul(T03, T34, T04);
     matrixMul(T04, T45, T05);
     matrixMul(T05, T56, T06);

     //获取位置（T06的第四列）
     for (int i = 0; i < 3; ++i) {
         cart[i] = T06[i][3];
     }
     //RPY角
     MatrixToRPY(T06, cart);

     for (int i = 0; i < 3; ++i) {
         cart[3 + i] *= RAD2DEG;
     }
 }


/*
* @brief: 逆解算，直接改变全局变量solution六个关节角的角度
* @param: cart：6个元素的一维数组，代表着位姿
* @output：解算成功的标志
* 解法详见：https://blog.csdn.net/weixin_43956732/article/details/106811100?fromshare=blogdetail&sharetype=blogdetail&sharerId=106811100&sharerefer=PC&sharesource=weixin_54383055&sharefrom=from_link
*/
 int Kinematics::inverse_kine(const Array& cart, map<std::string, Array_2>& solutionMap)
 {
     Array_2 solution(16, vector<double>(6, 0));//逆解数组
     double d1=dh.param_table[0].d;   double a1= dh.param_table[0].length;    double alp0 = dh.param_table[0].alpha;
     double d2=dh.param_table[1].d;   double a2= dh.param_table[1].length;    double alp1 = dh.param_table[1].alpha;
     double d3=dh.param_table[2].d;   double a3= dh.param_table[2].length;    double alp2 = dh.param_table[2].alpha;
     double d4=dh.param_table[3].d;   double a4= dh.param_table[3].length;    double alp3 = dh.param_table[3].alpha;
     double d5=dh.param_table[4].d;   double a5= dh.param_table[4].length;    double alp4 = dh.param_table[4].alpha;
     double d6=dh.param_table[5].d;   double a6= dh.param_table[5].length;    double alp5 = dh.param_table[5].alpha;


     int IKflag = 0;
     Array_2 T06(4, vector<double>(4, 0));
     RPYToMatrix(cart, T06);
     double nx = T06[0][0];
     double ox = T06[0][1];
     double ax = T06[0][2];
     double px = T06[0][3];

     double ny = T06[1][0];
     double oy = T06[1][1];
     double ay = T06[1][2];
     double py = T06[1][3];
     double nz = T06[2][0];
     double oz = T06[2][1];
     double az = T06[2][2];
     double pz = T06[2][3];
     double m = d6 * ay - py;
     double n = ax * d6 - px;

     double  ForJudgment = m * m + n * n - d4 * d4;
     if (ForJudgment < -1e-6)
     {
         printf("超出工作空间，无法求解(肩关节奇异)\n");   //机械臂末端中心点位于J1轴与J2轴所构成的平面导致奇异
         IKflag = -1;
         return IKflag;
     }
     else if (ForJudgment >= -1e-6 && ForJudgment < 1e-6)
     {
         ForJudgment = 0;
     }
     //求解theta1
     double   theta1_1 = atan2(m, n) - atan2(d4, sqrt(ForJudgment));
     double  theta1_2 = atan2(m, n) - atan2(d4, -sqrt(ForJudgment));
     double s1_1 = sin(theta1_1);      double c1_1 = cos(theta1_1);
     double s1_2 = sin(theta1_2);      double c1_2 = cos(theta1_2);

     //求解theta5
     double theta5_1 = 0; double theta5_2 = 0; double theta5_3 = 0; double theta5_4 = 0;


     double wrist_1 = ax * s1_1 - ay * c1_1;
     theta5_1 = acos(wrist_1);
     theta5_2 = -acos(wrist_1); //%%%%%%%%%%
     double s5_1;  double s5_2;
     double c5_1;  double c5_2;
     if (abs(wrist_1) - 1 <= 0)
     {
         s5_1 = sin(theta5_1); s5_2 = sin(theta5_2);
         c5_1 = cos(theta5_1); c5_2 = cos(theta5_2);
         if (abs(wrist_1) - 1 == 0)
         {
             s5_1 = +0.01;
             s5_2 = +0.01;
         }
     }
     else
     {
         printf("腕关节奇异，前两组角5无解\n");// J4和J6轴平行，导致奇异
     }
     double wrist_2 = ax * s1_2 - ay * c1_2;
     theta5_3 = acos(wrist_2);
     theta5_4 = -acos(wrist_2); //%%%%%%%%%%
     double s5_3; double s5_4;
     double c5_3; double c5_4;
     if (abs(wrist_2) - 1 <= 0)
     {
         s5_3 = sin(theta5_3);
         c5_3 = cos(theta5_3);
         s5_4 = sin(theta5_4);
         c5_4 = cos(theta5_4);
         if (abs(wrist_2) - 1 == 0)
         {
             s5_1 = +0.01;
             s5_2 = +0.01;
         }
     }
     else
     {
         printf("腕关节奇异，后两组角5无解\n");
     }

     //求解theta6
     double P1 = nx * s1_1 - ny * c1_1;       double P2 = nx * s1_2 - ny * c1_2;
     double Q1 = ox * s1_1 - oy * c1_1;       double Q2 = ox * s1_2 - oy * c1_2;

     double theta6_1 = atan2(P1, Q1) - atan2(s5_1, 0);
     double theta6_2 = atan2(P1, Q1) - atan2(s5_2, 0);
     double theta6_3 = atan2(P2, Q2) - atan2(s5_3, 0);
     double theta6_4 = atan2(P2, Q2) - atan2(s5_4, 0);
     double s6_1 = sin(theta6_1); double s6_2 = sin(theta6_2); double s6_3 = sin(theta6_3); double s6_4 = sin(theta6_4);
     double c6_1 = cos(theta6_1); double c6_2 = cos(theta6_2); double c6_3 = cos(theta6_3); double c6_4 = cos(theta6_4);
 
     //求解theta3
            //double A = d5 * (s6 * (nx * c1 + ny * s1) + c6 * (ox * c1 + oy * s1))-d6*(ax*c1+ay*s1) + px * c1+ py * s1;
            //double B = pz - d1 - az * d6 + d5*(oz * c6 + nz * s6);

     double A1 = d5 * (s6_1 * (nx * c1_1 + ny * s1_1) + c6_1 * (ox * c1_1 + oy * s1_1)) - d6 * (ax * c1_1 + ay * s1_1) + px * c1_1 + py * s1_1;
     double B1 = pz - d1 - az * d6 + d5 * (oz * c6_1 + nz * s6_1);
     double A2 = d5 * (s6_2 * (nx * c1_1 + ny * s1_1) + c6_2 * (ox * c1_1 + oy * s1_1)) - d6 * (ax * c1_1 + ay * s1_1) + px * c1_1 + py * s1_1;
     double B2 = pz - d1 - az * d6 + d5 * (oz * c6_2 + nz * s6_2);

     double A3 = d5 * (s6_3 * (nx * c1_2 + ny * s1_2) + c6_3 * (ox * c1_2 + oy * s1_2)) - d6 * (ax * c1_2 + ay * s1_2) + px * c1_2 + py * s1_2;
     double B3 = pz - d1 - az * d6 + d5 * (oz * c6_3 + nz * s6_3);
     double A4 = d5 * (s6_4 * (nx * c1_2 + ny * s1_2) + c6_4 * (ox * c1_2 + oy * s1_2)) - d6 * (ax * c1_2 + ay * s1_2) + px * c1_2 + py * s1_2;
     double B4 = pz - d1 - az * d6 + d5 * (oz * c6_4 + nz * s6_4);

     double theta3_1 = 0, theta3_2 = 0, theta3_3 = 0, theta3_4 = 0, theta3_5 = 0, theta3_6 = 0, theta3_7 = 0, theta3_8 = 0;
     if ((A1 * A1 + B1 * B1) <= pow((a2 + a3), 2))
     {
         if (A1 * A1 + B1 * B1 == pow((a2 + a3), 2))
         {
             printf("肘关节奇异，后续角2_1、2_2无法求解\n");
         }
         theta3_1 = acos((A1 * A1 + B1 * B1 - a2 * a2 - a3 * a3) / (2 * a2 * a3));
         theta3_2 = -acos((A1 * A1 + B1 * B1 - a2 * a2 - a3 * a3) / (2 * a2 * a3));
     }
     if ((A2 * A2 + B2 * B2) <= pow((a2 + a3), 2))
     {
         if (A2 * A2 + B2 * B2 == pow((a2 + a3), 2))
         {
             printf("肘关节奇异，后续角2_3、2_4无法求解\n");//机械臂大臂小臂在一条直线上导致奇异
         }
         theta3_3 = acos((A2 * A2 + B2 * B2 - a2 * a2 - a3 * a3) / (2 * a2 * a3));
         theta3_4 = -acos((A2 * A2 + B2 * B2 - a2 * a2 - a3 * a3) / (2 * a2 * a3));
     }
     if ((A3 * A3 + B3 * B3) <= pow((a2 + a3), 2))
     {
         if (A3 * A3 + B3 * B3 == pow((a2 + a3), 2))
         {
             printf("肘关节奇异，后续角2_5、2_6无法求解\n");
         }
         theta3_5 = acos((A3 * A3 + B3 * B3 - a2 * a2 - a3 * a3) / (2 * a2 * a3));
         theta3_6 = -acos((A3 * A3 + B3 * B3 - a2 * a2 - a3 * a3) / (2 * a2 * a3));
     }

     if ((A4 * A4 + B4 * B4) <= pow((a2 + a3), 2))
     {
         if (A4 * A4 + B4 * B4 == pow((a2 + a3), 2))
         {
             printf("肘关节奇异，后续角2_7、2_8无法求解\n");
         }
         theta3_7 = acos((A4 * A4 + B4 * B4 - a2 * a2 - a3 * a3) / (2 * a2 * a3));
         theta3_8 = -acos((A4 * A4 + B4 * B4 - a2 * a2 - a3 * a3) / (2 * a2 * a3));
     }
     double s3_1 = sin(theta3_1); double s3_2 = sin(theta3_2); double s3_3 = sin(theta3_3); double s3_4 = sin(theta3_4); double s3_5 = sin(theta3_5); double s3_6 = sin(theta3_6); double s3_7 = sin(theta3_7); double s3_8 = sin(theta3_8);
     double c3_1 = cos(theta3_1); double c3_2 = cos(theta3_2); double c3_3 = cos(theta3_3); double c3_4 = cos(theta3_4); double c3_5 = cos(theta3_5); double c3_6 = cos(theta3_6); double c3_7 = cos(theta3_7); double c3_8 = cos(theta3_8);

     //求解theta2

     double theta2_1, theta2_2, theta2_3, theta2_4, theta2_5, theta2_6, theta2_7, theta2_8;
     //double s2 = ((a3 * c3 + a2) * B - a3 * s3 * A) /( a2 * a2 + a3 * a3 + 2 * a2 * a3 * c3);
     //double c2 = (A + a3 * s3 * s2) / (a3 * c3 + a2);

     double s2_1 = ((a3 * c3_1 + a2) * B1 - a3 * s3_1 * A1) / (a2 * a2 + a3 * a3 + 2 * a2 * a3 * c3_1);
     double c2_1 = (A1 + a3 * s3_1 * s2_1) / (a3 * c3_1 + a2);
     theta2_1 = atan2(s2_1, c2_1);
     double s2_2 = ((a3 * c3_2 + a2) * B1 - a3 * s3_2 * A1) / (a2 * a2 + a3 * a3 + 2 * a2 * a3 * c3_2);
     double c2_2 = (A1 + a3 * s3_2 * s2_2) / (a3 * c3_2 + a2);
     theta2_2 = atan2(s2_2, c2_2);
     double s2_3 = ((a3 * c3_3 + a2) * B2 - a3 * s3_3 * A2) / (a2 * a2 + a3 * a3 + 2 * a2 * a3 * c3_3);
     double c2_3 = (A2 + a3 * s3_3 * s2_3) / (a3 * c3_3 + a2);
     theta2_3 = atan2(s2_3, c2_3);
     double s2_4 = ((a3 * c3_4 + a2) * B2 - a3 * s3_4 * A2) / (a2 * a2 + a3 * a3 + 2 * a2 * a3 * c3_4);
     double c2_4 = (A2 + a3 * s3_4 * s2_4) / (a3 * c3_4 + a2);
     theta2_4 = atan2(s2_4, c2_4);
     double s2_5 = ((a3 * c3_5 + a2) * B3 - a3 * s3_5 * A3) / (a2 * a2 + a3 * a3 + 2 * a2 * a3 * c3_5);
     double c2_5 = (A3 + a3 * s3_5 * s2_5) / (a3 * c3_5 + a2);
     theta2_5 = atan2(s2_5, c2_5);
     double s2_6 = ((a3 * c3_6 + a2) * B3 - a3 * s3_6 * A3) / (a2 * a2 + a3 * a3 + 2 * a2 * a3 * c3_6);
     double c2_6 = (A3 + a3 * s3_6 * s2_6) / (a3 * c3_6 + a2);
     theta2_6 = atan2(s2_6, c2_6);
     double s2_7 = ((a3 * c3_7 + a2) * B4 - a3 * s3_7 * A4) / (a2 * a2 + a3 * a3 + 2 * a2 * a3 * c3_7);
     double c2_7 = (A4 + a3 * s3_7 * s2_7) / (a3 * c3_7 + a2);
     theta2_7 = atan2(s2_7, c2_7);
     double s2_8 = ((a3 * c3_8 + a2) * B4 - a3 * s3_8 * A4) / (a2 * a2 + a3 * a3 + 2 * a2 * a3 * c3_8);
     double c2_8 = (A4 + a3 * s3_8 * s2_8) / (a3 * c3_8 + a2);
     theta2_8 = atan2(s2_8, c2_8);

     //求解theta4
     double theta4_1, theta4_2, theta4_3, theta4_4, theta4_5, theta4_6, theta4_7, theta4_8;
     theta4_1 = atan2(-s6_1 * (nx * c1_1 + ny * s1_1) - c6_1 * (ox * c1_1 + oy * s1_1), oz * c6_1 + nz * s6_1) - theta2_1 - theta3_1;
     theta4_2 = atan2(-s6_1 * (nx * c1_1 + ny * s1_1) - c6_1 * (ox * c1_1 + oy * s1_1), oz * c6_1 + nz * s6_1) - theta2_2 - theta3_2;
     theta4_3 = atan2(-s6_2 * (nx * c1_1 + ny * s1_1) - c6_2 * (ox * c1_1 + oy * s1_1), oz * c6_2 + nz * s6_2) - theta2_3 - theta3_3;
     theta4_4 = atan2(-s6_2 * (nx * c1_1 + ny * s1_1) - c6_2 * (ox * c1_1 + oy * s1_1), oz * c6_2 + nz * s6_2) - theta2_4 - theta3_4;
     theta4_5 = atan2(-s6_3 * (nx * c1_2 + ny * s1_2) - c6_3 * (ox * c1_2 + oy * s1_2), oz * c6_3 + nz * s6_3) - theta2_5 - theta3_5;
     theta4_6 = atan2(-s6_3 * (nx * c1_2 + ny * s1_2) - c6_3 * (ox * c1_2 + oy * s1_2), oz * c6_3 + nz * s6_3) - theta2_6 - theta3_6;
     theta4_7 = atan2(-s6_4 * (nx * c1_2 + ny * s1_2) - c6_4 * (ox * c1_2 + oy * s1_2), oz * c6_4 + nz * s6_4) - theta2_7 - theta3_7;
     theta4_8 = atan2(-s6_4 * (nx * c1_2 + ny * s1_2) - c6_4 * (ox * c1_2 + oy * s1_2), oz * c6_4 + nz * s6_4) - theta2_8 - theta3_8;

     solution[0][0] = theta1_1; solution[0][1] = theta2_1; solution[0][2] = theta3_1; solution[0][3] = theta4_1; solution[0][4] = theta5_1; solution[0][5] = theta6_1;
     solution[1][0] = theta1_1; solution[1][1] = theta2_2; solution[1][2] = theta3_2; solution[1][3] = theta4_2; solution[1][4] = theta5_1; solution[1][5] = theta6_1;
     solution[2][0] = theta1_1; solution[2][1] = theta2_3; solution[2][2] = theta3_3; solution[2][3] = theta4_3; solution[2][4] = theta5_2; solution[2][5] = theta6_2;
     solution[3][0] = theta1_1; solution[3][1] = theta2_4; solution[3][2] = theta3_4; solution[3][3] = theta4_4; solution[3][4] = theta5_2; solution[3][5] = theta6_2;
     solution[4][0] = theta1_2; solution[4][1] = theta2_5; solution[4][2] = theta3_5; solution[4][3] = theta4_5; solution[4][4] = theta5_3; solution[4][5] = theta6_3;
     solution[5][0] = theta1_2; solution[5][1] = theta2_6; solution[5][2] = theta3_6; solution[5][3] = theta4_6; solution[5][4] = theta5_3; solution[5][5] = theta6_3;
     solution[6][0] = theta1_2; solution[6][1] = theta2_7; solution[6][2] = theta3_7; solution[6][3] = theta4_7; solution[6][4] = theta5_4; solution[6][5] = theta6_4;
     solution[7][0] = theta1_2; solution[7][1] = theta2_8; solution[7][2] = theta3_8; solution[7][3] = theta4_8; solution[7][4] = theta5_4; solution[7][5] = theta6_4;

     for (int i = 0; i < 8; i++)            //将弧度初步限定在+-PI
     {
         for (int j = 0; j < 6; j++)
         {
             if (solution[i][j] <= -PI)
             {
                 solution[i][j] += 2 * PI;
             }
             else if (solution[i][j] >= PI)
             {
                 solution[i][j] -= 2 * PI;
             }
             solution[i][j] = solution[i][j] / PI * 180;
         }

     }


     //由于上面求解过程求出为绝对弧度，减去偏置，输出相对弧度
     for (int m = 0; m < 8; m++)
     {
         solution[m][1] -= dh.offset_j2 / PI * 180;
         solution[m][3] -= dh.offset_j4 / PI * 180;
     }


     solution = todouble_solution(solution);//将8组解通过六轴角度周期翻倍得到16组解
     //角度限制检测，但是此处已经为计算后的相对角度，所以DH参数中的角度限制也应该填相对参数
     bool bValid = true;
     Array_2 valid;
     Array_2 invalid;
     for (unsigned int i = 0; i < solution.size(); ++i)
     {
         bValid = true;
         for (unsigned int j = 0; j < solution[i].size(); ++j)
         {
             if (in_range(solution[i][j], &dh.param_table[j]) == false)
             {
                 bValid = false;
                 break;

             }
         }
         if (bValid)
         {
             valid.push_back(solution[i]);
         }
         else
         {
             invalid.push_back(solution[i]);
         }
     }
     solutionMap.insert(pair<string, Array_2>("valid", valid));
     solutionMap.insert(pair<string, Array_2>("invalid", invalid));
     if (valid.size() == 0)
     {
         IKflag = -2;
         return IKflag;//八组解都在关节限制之外
     }
     else
         return 0;

 }

 /*选择最优解（同时会对角度进行限制）*/
 Array Kinematics::OptimalJoint(map<std::string, Array_2>& solutionMap, Array Angle_Last) {
     Array_2 solution = solutionMap["valid"];
     double error = 0.0f;
     double error_min = 10000.0;
     /* 定义最优解 */
     Array  Optimal_joint(6);
     /* 存储误差最小时的组号 */
     int j = 0;


     /* 迭代求最小误差 */
     for (int i = 0; i < solution.size(); i++)
     {
         error = abs(solution[i][0] - Angle_Last[0]) * 0.16 + abs(solution[i][1] - Angle_Last[1]) * 0.16 +
             abs(solution[i][2] - Angle_Last[2]) * 0.16 + abs(solution[i][3] - Angle_Last[3]) * 0.16 +
             abs(solution[i][4] - Angle_Last[4]) * 0.16 + abs(solution[i][5] - Angle_Last[5]) * 0.16;
         if (error < error_min)
         {
             error_min = error;
             j = i;
         }
     }
     for (int i = 0; i < 6; i++)
     {
         Optimal_joint[i] = solution[j][i];
     }
     return Optimal_joint;
 }



 Array_2 Kinematics::todouble_solution(Array_2 solution)
 {
     //  Array_2 I(16, vector<double>(8, 0));

     for (int i = 0; i < 8; i++)
     {
         for (int j = 0; j < 6; j++)
         {
             solution[i + 8][j] = solution[i][j];
             if (j == 5)
             {
                 if (solution[i][j] < 0)
                 {
                     solution[i + 8][j] = solution[i][j] + 360;
                 }
                 else if (solution[i][j] > 0)
                 {
                     solution[i + 8][j] = solution[i][j] - 360;
                 }
             }
         }
     }

     return solution;
 }

 bool Kinematics::in_range(double val, param_t* par)
 {
     if (!par)  return false;
     return (val <= par->maxTheta + 0.00001 && val >= par->minTheta + 0.00001);  //由于关节角解算不精确，限制时考虑了极限角度下存在极小误差0.0001°
 }



 Array Kinematics::T_jacobian_i(Array_2 T) //求解相对工具坐标系的雅可比矩阵的某一列
 {
     Array jacobianTi(6);
     jacobianTi[0] = -T[0][0] * T[1][3] + T[1][0] * T[0][3];
     jacobianTi[1] = -T[0][1] * T[1][3] + T[1][1] * T[0][3];
     jacobianTi[0] = -T[0][2] * T[1][3] + T[1][2] * T[0][3];
     jacobianTi[0] = T[2][0];
     jacobianTi[0] = T[2][1];
     jacobianTi[0] = T[2][2];
     return jacobianTi;
 }
 //相对雅克比矩阵求解(微分变换法)
 Array_2  Kinematics::T_jacobian(Array_2 T06, Array_2 T16, Array_2 T26, Array_2 T36, Array_2 T46, Array_2 T56)
 {
     Array_2 T_jacobian(6, vector<double>(6, 0));//相对于末端的雅可比
     Array_2 T_jacobianT(6, vector<double>(6, 0));//相对雅可比的转置矩阵(这样做的原因是列向量合成矩阵不便，则先以行向量的形式合成，再转置为雅可比矩阵)
     T_jacobianT[0] = T_jacobian_i(T06);
     T_jacobianT[1] = T_jacobian_i(T16);
     T_jacobianT[2] = T_jacobian_i(T26);
     T_jacobianT[3] = T_jacobian_i(T36);
     T_jacobianT[4] = T_jacobian_i(T46);
     T_jacobianT[5] = T_jacobian_i(T56);
     T_jacobian = matrix_translate(T_jacobianT);//完成转置
     return T_jacobian;
 }
 //雅可比矩阵
 Array_2  Kinematics::jacobian(Array_2 T_jacobian, Array_2 T06)
 {
     Array_2 jacobian(6, vector<double>(6, 0));
     Array_2 TRR(6, vector<double>(6, 0));  //微分变换法中的6*6右对角矩阵，对角线为两姿态阵R（3*3）、R（3*3）；
     TRR[0][0] = T06[0][0];  TRR[0][1] = T06[0][1];   TRR[0][2] = T06[0][2];
     TRR[1][0] = T06[1][0];  TRR[1][1] = T06[1][1];   TRR[1][2] = T06[1][2];
     TRR[2][0] = T06[2][0];  TRR[2][1] = T06[2][1];   TRR[2][2] = T06[2][2];
     TRR[3][3] = T06[3][3];  TRR[3][4] = T06[3][4];   TRR[3][5] = T06[3][5];
     TRR[4][3] = T06[4][3];  TRR[4][4] = T06[4][4];   TRR[4][5] = T06[4][5];
     TRR[5][3] = T06[5][3];  TRR[5][4] = T06[5][4];   TRR[5][5] = T06[5][5];
     jacobian = matrix6mul6(TRR, T_jacobian);     //jacobian==TRR*T_jacobian
     return jacobian;

 }
 Array_2  Kinematics::get_jacobian(Array_2 T06, Array_2 T16, Array_2 T26, Array_2 T36, Array_2 T46, Array_2 T56)
 {
     Array_2 jacobianT(6, vector<double>(6, 0));//相对于末端的雅可比
     Array_2 jacobian0(6, vector<double>(6, 0));//相对于末端的雅可比
     jacobianT = T_jacobian(T06, T16, T26, T36, T46, T56);
     jacobian0 = jacobian(jacobianT, T06);
     return jacobian0;
 }

   