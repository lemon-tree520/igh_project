机械臂部分程序：vscode中编译：g++ -o main igh_dc_motor.cpp main.cpp Supervision.cpp MoveFunction.cpp Kinematics.cpp DHparam.cpp TrajectoryPlanning.cpp Utils.cpp 
运行：  ./main