#include "DHparam.h"
//#include <string.h>
#include "Utils.h"

DHParam::DHParam()
{

    offset_j2 = -PI / 2;
    offset_j4 = -PI / 2;
    //此处限位为相对,该表格只需要填写限位角度，DH参数不需要填，UR板本在Kinematics.cpp中写了DH参数。绝对角度限制为+-170
    param_table[0] = { 0,   91,     0,        PI/2,     -170,   170 };
    param_table[1] = { 0,   0,     -414,      0,         -80,   260 };//偏置-90
    param_table[2] = { 0,   0,     -400,      0,        -170,   170 };
    param_table[3] = { 0,   145,    0,        PI/2,     - 80,   260 };
    param_table[4] = { 0,   105,    0,      - PI/2,    - 170,   170 };//偏置-90
    param_table[5] = { 0,   60,     0,        0,        -170,   170 };
}
