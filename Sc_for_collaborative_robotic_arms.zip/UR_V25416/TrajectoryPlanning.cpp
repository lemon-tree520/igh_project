#include "TrajectoryPlanning.h"
#include<iostream>
#include <cmath>
using namespace std;
TrajectoryPlanning::TrajectoryPlanning()
{

};
TrajectoryPlanning::~TrajectoryPlanning()
{

};

/*
 * 梯形规划函数，其中所有的值都应该为矢量
 */
DataArray TrajectoryPlanning::ComponentsPlanning(	
													double startPosition,// 起始位置（矢量）												
													double startVelocity,// 起始速度（矢量）													
													double startAcceleration,// 起始加速度（矢量）												
													double endPosition,// 终止位置（矢量）													
													double endVelocity,// 终止速度（矢量）													
													double endAcceleration,// 终止加速度（矢量）
													double maxVelocity,// 最大速度（矢量）												
													double acceleration,// 加速度（矢量）
													double period) // 插补周期
{
	// 输出数据
	DataArray dataArray;

	DataArray erro(1); erro[0].acceleration = 0; erro[0].positon = startPosition; erro[0].time = 0; erro[0].velocity = 0;
	if (fabs(endPosition - startPosition) < 0.01)return erro;

	//方向标志，0为正方向，1为负方向
	bool directionFlag = 0;
	if ((endPosition - startPosition) < 0)
		directionFlag = 1;
	else
		directionFlag = 0;


	// 情况1：起始加速度>0 && 终止加速度<0
	if ((startAcceleration > 0 && endAcceleration < 0 && directionFlag == 0) || (startAcceleration < 0 && endAcceleration > 0 && directionFlag == 1))
	{
		dataArray = Situation1(startPosition, endPosition, maxVelocity, startVelocity, endVelocity, acceleration, period, startAcceleration, endAcceleration);
	}
	// 情况2：起始加速度>0 && 终止加速度>0
	if ((startAcceleration > 0 && endAcceleration > 0 && directionFlag == 0) || (startAcceleration < 0 && endAcceleration < 0 && directionFlag == 1))
	{
		dataArray = Situation2(startPosition, endPosition, maxVelocity, startVelocity, endVelocity, acceleration, period, startAcceleration, endAcceleration);
	}
	// 情况3：起始加速度>0 && 终止加速度=0
	if ((startAcceleration > 0 && endAcceleration == 0 && directionFlag == 0) || (startAcceleration < 0 && endAcceleration == 0 && directionFlag == 1))
	{
		dataArray = Situation3(startPosition, endPosition, maxVelocity, startVelocity, endVelocity, acceleration, period, startAcceleration, endAcceleration);
	}
	// 情况4：起始加速度=0 && 终止加速度=0
	if ((startAcceleration == 0 && endAcceleration == 0 && directionFlag == 0) || (startAcceleration == 0 && endAcceleration == 0 && directionFlag == 1))
	{
		dataArray = Situation4(startPosition, endPosition, maxVelocity, startVelocity, endVelocity, acceleration, period, startAcceleration, endAcceleration);
	}
	// 情况5：起始加速度=0 && 终止加速度<0
	if ((startAcceleration == 0 && endAcceleration < 0 && directionFlag == 0) || (startAcceleration == 0 && endAcceleration > 0 && directionFlag == 1))
	{
		dataArray = Situation5(startPosition, endPosition, maxVelocity, startVelocity, endVelocity, acceleration, period, startAcceleration, endAcceleration);
	}
	// 情况6：起始加速度<0 && 终止加速度<0
	if ((startAcceleration < 0 && endAcceleration < 0 && directionFlag == 0) || (startAcceleration > 0 && endAcceleration > 0 && directionFlag == 1))
	{
		dataArray = Situation6(startPosition, endPosition, maxVelocity, startVelocity, endVelocity, acceleration, period, startAcceleration, endAcceleration);
	}

	return dataArray;
}
DataArray TrajectoryPlanning::Situation1(
	double startPosition,
	double endPosition,
	double maxVelocity,
	double startVelocity,
	double endVelocity,
	double acceleration,
	double period,
	double startAcceleration,
	double endAcceleration)
{

	// 情况1：起始速度 < 最大速度 && 终止速度 < 最大速度
	// 情况1.1：
	// 式子：(终止位置 - 起始位置 - ((最大速度^2 - 初始速度^2) / 2 * 加速度 + (最大速度^2 - 终止速度^2) /( 2 * 加速度))) > 0
	// 则有：
	bool f1Flag = (fabs(endPosition - startPosition) - fabs((2 * pow(maxVelocity, 2) - pow(startVelocity, 2) - pow(endVelocity, 2)) / (2 * acceleration))) > 0;
	if (f1Flag)
	{
		// 加速时间 = (最大速度 - 初始速度) / 加速度
		double accTime = (maxVelocity - startVelocity) / acceleration;
		// 加速路程 = 1/2 * (初始速度 + 最大速度) * 加速时间
		double accDistance = 0.5 * accTime * (maxVelocity + startVelocity);

		// 减速时间 = (最大速度 - 终止速度) / 加速度
		double dAccTime = (maxVelocity - endVelocity) / acceleration;
		// 减速路程 = (最大速度 + 终止速度) / 2 * 减速时间
		double dAccDistance = 0.5 * (maxVelocity + endVelocity) * dAccTime;

		// 总路程 = 终止位置 - 起始位置
		double allDistance = endPosition - startPosition;

		// 匀速路程 = 总路程 - 加速路程 - 减速路程
		double uniDistance = allDistance - accDistance - dAccDistance;
		// 匀速时间 = 匀速路程 / 最大速度
		double uniTime = uniDistance / maxVelocity;
		// 总时间 = 加速时间 + 匀速时间 + 减速时间
		double allTime = accTime + uniTime + dAccTime;
		// 插补数量 = 向上取整(总时间 / 插补周期)
		int interpolationNum = ceil(allTime / period);

		// 数据数组
		DataArray dataArray(interpolationNum);
		// 设置时间
		for (size_t i = 0; i < interpolationNum; i++)
		{
			// 初始状态设置
			if (i == 0)
			{
				dataArray[i].time = 0.0;
			}
			// 每周期的状态设置
			else
			{
				dataArray[i].time = dataArray[i - 1].time + period;
			}
		}
		// 设置其他数据
		dataArray[0].positon = startPosition;
		dataArray[0].velocity = startVelocity;
		dataArray[0].acceleration = startAcceleration;
		for (size_t i = 0; i < interpolationNum; i++)
		{
			// 如果是加速时间
			bool accTimeFlag = dataArray[i].time <= accTime;
			if (accTimeFlag && i > 0)
			{
				dataArray[i].positon = dataArray[i - 1].positon + dataArray[i - 1].velocity * period + 0.5 * acceleration * pow(period, 2);
				dataArray[i].velocity = dataArray[i - 1].velocity + acceleration * period;
				dataArray[i].acceleration = acceleration;
			}
			// 如果是匀速时间
			bool uniTimeFlag = dataArray[i].time > accTime && dataArray[i].time <= accTime + uniTime;
			if (uniTimeFlag && i > 0)
			{
				dataArray[i].positon = dataArray[i - 1].positon + maxVelocity * period;
				dataArray[i].velocity = maxVelocity;
				dataArray[i].acceleration = 0;
			}
			// 如果是减速时间
			bool dAccTimeFlag = dataArray[i].time > accTime + uniTime && dataArray[i].time <= allTime;
			if (dAccTimeFlag && i > 0)
			{
				dataArray[i].positon = dataArray[i - 1].positon + dataArray[i - 1].velocity * period - 0.5 * acceleration * pow(period, 2);
				dataArray[i].velocity = dataArray[i - 1].velocity - acceleration * period;
				dataArray[i].acceleration = -acceleration;
			}
		}
		return dataArray;
	}
	// 情况1.2：
	else
	{
		// 计算实际最大速度
		// 实际最大速度 = √((2 * 加速度 * (终止位置 - 起始位置) + 起始速度^2 + 终止速度^2) / 2)
		double maxVelocityReal = sqrt((2 * acceleration * (endPosition - startPosition) + pow(startVelocity, 2) + pow(endVelocity, 2)) / 2);
		if ((endPosition - startPosition) < 0)
			maxVelocityReal = -maxVelocityReal;

		// 加速时间 = (实际最大速度 - 初始速度) / 加速度
		double accTime = (maxVelocityReal - startVelocity) / acceleration;
		// 加速路程 = 1/2 * (初始速度 + 实际最大速度) * 加速时间
		double accDistance = 0.5 * accTime * (maxVelocityReal + startVelocity);

		// 减速时间 = (实际最大速度 - 终止速度) / 加速度
		double dAccTime = (maxVelocityReal - endVelocity) / acceleration;
		// 减速路程 = (实际最大速度 + 终止速度) / 2 * 减速时间
		double dAccDistance = 0.5 * (maxVelocityReal + endVelocity) * dAccTime;

		// 总路程 = 终止位置 - 起始位置
		double allDistance = endPosition - startPosition;
		// 总时间 = 加速时间 + 减速时间
		double allTime = accTime + dAccTime;
		// 插补数量 = 向上取整(总时间 / 插补周期)
		int interpolationNum = ceil(allTime / period);

		// 数据数组
		DataArray dataArray(interpolationNum);
		// 设置时间
		for (size_t i = 0; i < interpolationNum; i++)
		{
			// 初始状态设置
			if (i == 0)
			{
				dataArray[i].time = 0.0;
			}
			// 每周期的状态设置
			else
			{
				dataArray[i].time = dataArray[i - 1].time + period;
			}
		}
		// 设置其他数据
		dataArray[0].positon = startPosition;
		dataArray[0].velocity = startVelocity;
		dataArray[0].acceleration = startAcceleration;
		for (size_t i = 0; i < interpolationNum; i++)
		{
			// 如果是加速时间
			bool accTimeFlag = dataArray[i].time <= accTime;
			if (accTimeFlag && i > 0)
			{
				dataArray[i].positon = dataArray[i - 1].positon + dataArray[i - 1].velocity * period + 0.5 * acceleration * pow(period, 2);
				dataArray[i].velocity = dataArray[i - 1].velocity + acceleration * period;
				dataArray[i].acceleration = acceleration;
			}
			// 如果是减速时间
			bool dAccTimeFlag = dataArray[i].time > accTime && dataArray[i].time <= allTime;
			if (dAccTimeFlag && i > 0)
			{
				dataArray[i].positon = dataArray[i - 1].positon + dataArray[i - 1].velocity * period - 0.5 * acceleration * pow(period, 2);
				dataArray[i].velocity = dataArray[i - 1].velocity - acceleration * period;
				dataArray[i].acceleration = -acceleration;
			}
		}
		return dataArray;
	}

}

DataArray TrajectoryPlanning::Situation2(
	double startPosition,
	double endPosition,
	double maxVelocity,
	double startVelocity,
	double endVelocity,
	double acceleration,
	double period,
	double startAcceleration,
	double endAcceleration)
{
	// 加速时间 = (终止速度 - 初始速度) / 加速度
	double accTime = (endVelocity - startVelocity) / acceleration;
	// 加速路程 = 1/2 * (初始速度 + 终止速度) * 加速时间
	double accDistance = 0.5 * accTime * (maxVelocity + endVelocity);
	// 总路程 = 加速路程
	double allDistance = accDistance;
	// 总时间 = 加速时间
	double allTime = accTime;
	// 插补数量 = 向上取整(总时间 / 插补周期)
	int interpolationNum = ceil(allTime / period);
	// 数据数组
	DataArray dataArray(interpolationNum);
	// 设置时间
	for (size_t i = 0; i < interpolationNum; i++)
	{
		// 初始状态设置
		if (i == 0)
		{
			dataArray[i].time = 0.0;
		}
		// 每周期的状态设置
		else
		{
			dataArray[i].time = dataArray[i - 1].time + period;
		}


	}
	// 设置其他数据
	dataArray[0].positon = startPosition;
	dataArray[0].velocity = startVelocity;
	dataArray[0].acceleration = startAcceleration;
	for (size_t i = 0; i < interpolationNum; i++)
	{
		// 如果是加速时间
		bool accTimeFlag = dataArray[i].time <= accTime;
		if (accTimeFlag && i > 0)
		{
			dataArray[i].positon = dataArray[i - 1].positon + dataArray[i - 1].velocity * period + 0.5 * acceleration * pow(period, 2);
			dataArray[i].velocity = dataArray[i - 1].velocity + acceleration * period;
			dataArray[i].acceleration = acceleration;
		}
	}
	return dataArray;
}

DataArray TrajectoryPlanning::Situation3(
	double startPosition,
	double endPosition,
	double maxVelocity,
	double startVelocity,
	double endVelocity,
	double acceleration,
	double period,
	double startAcceleration,
	double endAcceleration)
{
	// 加速时间 = (最大速度 - 初始速度) / 加速度
	double accTime = (maxVelocity - startVelocity) / acceleration;
	// 加速路程 = 1/2 * (初始速度 + 最大速度) * 加速时间
	double accDistance = 0.5 * accTime * (maxVelocity + startVelocity);
	// 总路程 = 终止位置 - 起始位置
	double allDistance = endPosition - startPosition;
	// 匀速路程 = 总路程 - 加速路程
	double uniDistance = allDistance - accDistance;
	// 匀速时间 = 匀速路程 / 最大速度
	double uniTime = uniDistance / maxVelocity;
	// 总时间 = 加速时间 + 匀速时间
	double allTime = accTime + uniTime;
	// 插补数量 = 向上取整(总时间 / 插补周期)
	int interpolationNum = ceil(allTime / period);
	// 数据数组
	DataArray dataArray(interpolationNum);
	// 设置时间
	for (size_t i = 0; i < interpolationNum; i++)
	{
		// 初始状态设置
		if (i == 0)
		{
			dataArray[i].time = 0.0;
		}
		// 每周期的状态设置
		else
		{
			dataArray[i].time = dataArray[i - 1].time + period;
		}


	}
	// 设置其他数据
	dataArray[0].positon = startPosition;
	dataArray[0].velocity = startVelocity;
	dataArray[0].acceleration = startAcceleration;
	for (size_t i = 0; i < interpolationNum; i++)
	{
		// 如果是加速时间
		bool accTimeFlag = dataArray[i].time <= accTime;
		if (accTimeFlag && i > 0)
		{
			dataArray[i].positon = dataArray[i - 1].positon + dataArray[i - 1].velocity * period + 0.5 * acceleration * pow(period, 2);
			dataArray[i].velocity = dataArray[i - 1].velocity + acceleration * period;
			dataArray[i].acceleration = acceleration;
		}

		bool uniTimeFlag = dataArray[i].time > accTime && dataArray[i].time <= accTime + uniTime;
		if (uniTimeFlag && i > 0)
		{
			dataArray[i].positon = dataArray[i - 1].positon + maxVelocity * period;
			dataArray[i].velocity = maxVelocity;
			dataArray[i].acceleration = 0;
		}
	}
	return dataArray;
}

DataArray TrajectoryPlanning::Situation4(
	double startPosition,
	double endPosition,
	double maxVelocity,
	double startVelocity,
	double endVelocity,
	double acceleration,
	double period,
	double startAcceleration,
	double endAcceleration)
{

	// 总路程 = 终止位置 - 起始位置
	double allDistance = endPosition - startPosition;
	// 匀速路程 = 总路程
	double uniDistance = allDistance;
	// 匀速时间 = 匀速路程 / 最大速度
	double uniTime = uniDistance / maxVelocity;
	// 总时间 = 匀速时间
	double allTime = uniTime;
	// 插补数量 = 向上取整(总时间 / 插补周期)
	int interpolationNum = ceil(allTime / period);
	// 数据数组
	DataArray dataArray(interpolationNum);
	// 设置时间
	for (size_t i = 0; i < interpolationNum; i++)
	{
		// 初始状态设置
		if (i == 0)
		{
			dataArray[i].time = 0.0;
		}
		// 每周期的状态设置
		else
		{
			dataArray[i].time = dataArray[i - 1].time + period;
		}


	}
	// 设置其他数据
	dataArray[0].positon = startPosition;
	dataArray[0].velocity = startVelocity;
	dataArray[0].acceleration = startAcceleration;
	for (size_t i = 0; i < interpolationNum; i++)
	{
		bool uniTimeFlag = dataArray[i].time <= uniTime;
		if (uniTimeFlag && i > 0)
		{
			dataArray[i].positon = dataArray[i - 1].positon + maxVelocity * period;
			dataArray[i].velocity = maxVelocity;
			dataArray[i].acceleration = 0;
		}
	}
	return dataArray;

}

DataArray TrajectoryPlanning::Situation5(
	double startPosition,
	double endPosition,
	double maxVelocity,
	double startVelocity,
	double endVelocity,
	double acceleration,
	double period,
	double startAcceleration,
	double endAcceleration)
{
	// 减速时间 = (最大速度 - 终止速度) / 加速度
	double dAccTime = (maxVelocity - endVelocity) / acceleration;
	// 减速路程 = (最大速度 + 终止速度) / 2 * 减速时间
	double dAccDistance = (maxVelocity + endVelocity) / 2 * dAccTime;

	// 总路程 = 终止位置 - 起始位置
	double allDistance = endPosition - startPosition;

	// 匀速路程 = 总路程- 减速路程
	double uniDistance = allDistance - dAccDistance;
	// 匀速时间 = 匀速路程 / 最大速度
	double uniTime = uniDistance / maxVelocity;
	// 总时间 = 匀速时间 + 减速时间
	double allTime = uniTime + dAccTime;
	// 插补数量 = 向上取整(总时间 / 插补周期)
	int interpolationNum = ceil(allTime / period);

	// 数据数组
	DataArray dataArray(interpolationNum);
	// 设置时间
	for (size_t i = 0; i < interpolationNum; i++)
	{
		// 初始状态设置
		if (i == 0)
		{
			dataArray[i].time = 0.0;
		}
		// 每周期的状态设置
		else
		{
			dataArray[i].time = dataArray[i - 1].time + period;
		}


	}
	// 设置其他数据
	dataArray[0].positon = startPosition;
	dataArray[0].velocity = startVelocity;
	dataArray[0].acceleration = startAcceleration;
	for (size_t i = 0; i < interpolationNum; i++)
	{
		// 如果是匀速时间
		bool uniTimeFlag = dataArray[i].time <= uniTime;
		if (uniTimeFlag && i > 0)
		{
			dataArray[i].positon = dataArray[i - 1].positon + maxVelocity * period;
			dataArray[i].velocity = maxVelocity;
			dataArray[i].acceleration = 0;
		}
		// 如果是减速时间
		bool dAccTimeFlag = dataArray[i].time > uniTime && dataArray[i].time <= allTime;
		if (dAccTimeFlag && i > 0)
		{
			dataArray[i].positon = dataArray[i - 1].positon + dataArray[i - 1].velocity * period - 0.5 * acceleration * pow(period, 2);
			dataArray[i].velocity = dataArray[i - 1].velocity - acceleration * period;
			dataArray[i].acceleration = -acceleration;
		}
	}
	return dataArray;
}

DataArray TrajectoryPlanning::Situation6(
	double startPosition,
	double endPosition,
	double maxVelocity,
	double startVelocity,
	double endVelocity,
	double acceleration,
	double period,
	double startAcceleration,
	double endAcceleration)
{
	// 减速时间 = (起始速度 - 终止速度) / 加速度
	double dAccTime = (startVelocity - endVelocity) / acceleration;
	// 减速路程 = (起始速度 + 终止速度) / 2 * 减速时间
	double dAccDistance = (startVelocity + endVelocity) / 2 * dAccTime;
	// 总路程 = 终止位置 - 起始位置
	double allDistance = endPosition - startPosition;
	// 总时间 =减速时间
	double allTime = dAccTime;
	// 插补数量 = 向上取整(总时间 / 插补周期)
	int interpolationNum = ceil(allTime / period);

	// 数据数组
	DataArray dataArray(interpolationNum);
	// 设置时间
	for (size_t i = 0; i < interpolationNum; i++)
	{
		// 初始状态设置
		if (i == 0)
		{
			dataArray[i].time = 0.0;
		}
		// 每周期的状态设置
		else
		{
			dataArray[i].time = dataArray[i - 1].time + period;
		}


	}
	// 设置其他数据
	dataArray[0].positon = startPosition;
	dataArray[0].velocity = startVelocity;
	dataArray[0].acceleration = startAcceleration;
	for (size_t i = 0; i < interpolationNum; i++)
	{
		// 如果是减速时间
		bool dAccTimeFlag = dataArray[i].time <= allTime;
		if (dAccTimeFlag && i > 0)
		{
			dataArray[i].positon = dataArray[i - 1].positon + dataArray[i - 1].velocity * period - 0.5 * acceleration * pow(period, 2);
			dataArray[i].velocity = dataArray[i - 1].velocity - acceleration * period;
			dataArray[i].acceleration = -acceleration;
		}
	}
	return dataArray;
}

/*定步长匀速笛卡尔直线插补
输入：起始点角度、终点位姿、插补数量
*输出：插补角度序列*/
Array_2 TrajectoryPlanning::UniformV_CartesianLinePlanning(Array CurJoint, Array EndJoint, double  spacing_n, double period)
{
	Array startcart(6);
	Array endcart(6);
	Array data_X(spacing_n + 1);
	Array data_Y(spacing_n + 1);
	Array data_Z(spacing_n + 1);
	trajKine.forward_kine(CurJoint, startcart);
	trajKine.forward_kine(EndJoint, endcart);
	Coordinate startCoordinate = { startcart[0],startcart[1], startcart[2], startcart[3], startcart[4], startcart[5] };
	Coordinate endCoordinate = { endcart[0],endcart[1], endcart[2], endcart[3], endcart[4], endcart[5] };
	struct Vector3D {
		double x;
		double y;
		double z;
	};
	Vector3D diff = { endCoordinate.X - startCoordinate.X, endCoordinate.Y - startCoordinate.Y, endCoordinate.Z - startCoordinate.Z };
	// 计算向量的长度
	double length = std::sqrt(diff.x * diff.x + diff.y * diff.y + diff.z * diff.z);
	if (length == 0)
	{
		throw "输入为同一点，规划失败";
	}
	else
	{
		double Increments = length / (spacing_n + 1);
		printf("直线规划步长间距为:%f\n", Increments);
	}
	Array Increments_unit(3);
	//计算各分量步长
	Increments_unit[0] = diff.x / (spacing_n);
	Increments_unit[1] = diff.y / (spacing_n);
	Increments_unit[2] = diff.z / (spacing_n);
	for (int i = 0; i < spacing_n + 1; i++)
	{
		data_X[i] = startcart[0] + Increments_unit[0] * i;
		data_Y[i] = startcart[1] + Increments_unit[1] * i;
		data_Z[i] = startcart[2] + Increments_unit[2] * i;
	}
	//进行姿态均匀弥散化
	Array_2 allRPY(3, vector<double>(spacing_n + 1));
	allRPY = TrajectoryPlanning::EulerAnglePlanning(startCoordinate.Roll, startCoordinate.Pitch, startCoordinate.Yaw, endCoordinate.Roll, endCoordinate.Pitch, endCoordinate.Yaw, spacing_n + 1);





	int flag;//判断逆解是否在工作范围内
	Array_2 CoordinatePose(spacing_n + 1, vector<double>(6, 0));//所有的位姿结果
	Array_2 Angle(spacing_n, vector<double>(6, 0));//所有的关节角结果
	Array optimal_joint(6);//最优逆解
	map<std::string, Array_2> solutionMap;
	Array cart(6);//笛卡尔坐标数组
	for (int i = 0; i < spacing_n + 1; i++)
	{
		CoordinatePose[i][0] = data_X[i];
		CoordinatePose[i][1] = data_Y[i];
		CoordinatePose[i][2] = data_Z[i];
		CoordinatePose[i][3] = allRPY[i][0];
		CoordinatePose[i][4] = allRPY[i][1];
		CoordinatePose[i][5] = allRPY[i][2];

	}





	//初始状态
	Angle[0] = CurJoint;
	for (int i = 1; i < spacing_n; i++) {

		map<std::string, Array_2> solutionMap;
		flag = trajKine.inverse_kine(CoordinatePose[i], solutionMap);
		if (flag == -1)
		{
			//FLAG = 1;
			printf("角度超出关节范围The %dth interpolation result reached the joint limit\nJoint position:%f %f %f %f %f %f\n"
				, i, Angle[i - 1][0], Angle[i - 1][1], Angle[i - 1][2], Angle[i - 1][3], Angle[i - 1][4], Angle[i - 1][5]);
			break;
		}//0为正常，1号错误：逆解超出绝对工作范围
		optimal_joint = trajKine.OptimalJoint(solutionMap, Angle[i - 1]);  //将择优解赋给optimal_joint，无解则给Angle[i-1]

		//如果出现关节反转的情况，则停止插补，最后的返回结果为直到极限位置的插补结果
		if ((fabs(optimal_joint[0] - Angle[i - 1][0]) > 20)
			|| (fabs(optimal_joint[1] - Angle[i - 1][1]) > 20)
			|| (fabs(optimal_joint[2] - Angle[i - 1][2]) > 20)
			|| (fabs(optimal_joint[3] - Angle[i - 1][3]) > 20)
			|| (fabs(optimal_joint[4] - Angle[i - 1][4]) > 20)
			|| (fabs(optimal_joint[5] - Angle[i - 1][5]) > 20))    //六个关节前后两次插补相差10°以上则报错
		{
			printf("前后角度超差The %dth interpolation result reached the joint limit\nJoint position:%f %f %f %f %f %f\n"
				, i, Angle[i - 1][0], Angle[i - 1][1], Angle[i - 1][2], Angle[i - 1][3], Angle[i - 1][4], Angle[i - 1][5]);
			printf("逆解角度为:%f %f %f %f %f %f\n", optimal_joint[0], optimal_joint[1], optimal_joint[2], optimal_joint[3], optimal_joint[4], optimal_joint[5]);
			//FLAG = 2;//0为正常，2号错误：终点超出关节角度限制
			break;
		}
		/*将最优解依次赋值给元素*/
		Angle[i] = optimal_joint;
	}

	////速度计算，°每秒
	//// 创建一个n行12列的新矩阵
	Array_2 result(Angle.size(), vector<double>(12));
	//// 填充新矩阵的前半部分（角度部分）
	for (std::size_t i = 0; i < Angle.size(); ++i) {
		for (std::size_t j = 0; j < 6; ++j) {
			result[i][j] = Angle[i][j];
		}
	}
	////初速度
	for (int j = 0; j < 6; ++j) {
		result[0][j + 6] = (result[1][j] - result[0][j]) / period;
	}
	////中间速度
	for (int i = 1; i < result.size(); ++i) {
		for (int j = 0; j < 6; ++j) {
			result[i][j + 6] = (result[i][j] - result[i - 1][j]) / period;
		}
	}
	////末速度为0
	//for (int j = 0; j < 6; ++j) {
	//	result[(result.size()) - 1][j + 6] = 0;
	//}


	return result;

}

////定步长笛卡尔圆弧插补
//输入：笛卡尔空间圆弧三点、插补数量、插补周期
//输出：插补角度序列
Array_2 TrajectoryPlanning::UniformV_CartesianCirclePlanning(Array StartJoint, Array MidJoint, Array EndJoint, double  spacing_n, double period)
{
	Array_2 angle(spacing_n + 1, vector<double>(6));
	Array_2 all_Q(spacing_n + 1, vector<double>(4));//在圆弧平面内插补二维坐标点
	Array_2 all_P(spacing_n + 1, vector<double>(4));//用于存放在机械臂笛卡尔空间下的三维坐标点。
	Array_2 result(spacing_n + 1, vector<double>(12, 0));
	Array_2 no_result(1, vector<double>(12, 0));
	Array startcart(6);
	Array midcart(6);
	Array endcart(6);
	trajKine.forward_kine(StartJoint, startcart);
	trajKine.forward_kine(MidJoint, midcart);
	trajKine.forward_kine(EndJoint, endcart);
	Coordinate StartCoordinate = { startcart[0],startcart[1], startcart[2], startcart[3], startcart[4], startcart[5] };
	Coordinate MidCoordinate = { midcart[0],midcart[1], midcart[2], midcart[3], midcart[4], midcart[5] };
	Coordinate EndCoordinate = { endcart[0],endcart[1], endcart[2], endcart[3], endcart[4], endcart[5] };
	printf("起点位姿为：");
	for (int i = 0; i < 6; i++)
	{
		std::cout << startcart[i] << "  ";
	}
	cout << endl;
	printf("中间点位姿为：");
	for (int i = 0; i < 6; i++)
	{
		cout << midcart[i] << "  ";
	}
	cout << endl;
	printf("终点位姿为：");
	for (int i = 0; i < 6; i++)
	{
		cout << endcart[i] << "  ";
	}
	cout << endl;

	Array v1(3), v2(3); // 三点生成两向量
	Array unit_v1(3), unit_v2(3), unit_n(3);//对应的单位向量
	v1[0] = midcart[0] - startcart[0]; v1[1] = midcart[1] - startcart[1]; v1[2] = midcart[2] - startcart[2];
	v2[0] = endcart[0] - midcart[0]; v2[1] = endcart[1] - midcart[1]; v2[2] = endcart[2] - midcart[2];
	double Long_v1 = sqrt(pow(v1[0], 2) + pow(v1[1], 2) + pow(v1[2], 2));
	double Long_v2 = sqrt(pow(v2[0], 2) + pow(v2[1], 2) + pow(v2[2], 2));
	// 判定输入三点是否存在两点位置相同
	if (abs(Long_v1) <= 1e-6 || abs(Long_v2) <= 1e-6)
	{
		if (abs(Long_v1) > 1e-3 && abs(Long_v2) <= 1e-6)
		{
			printf("输入中间点与终止点重合，故将以直线插补形式完成规划\n");
			result = TrajectoryPlanning::UniformV_CartesianLinePlanning(StartJoint, MidJoint, spacing_n, period);    //以定步长插补直线规划运动到终止点  
			return result;
		}
		else if ((abs(Long_v1) <= 1e-6 && abs(Long_v2) > 1e-3))
		{
			printf("输入起始点与中间点重合，故将以直线插补形式完成规划\n");
			result = TrajectoryPlanning::UniformV_CartesianLinePlanning(StartJoint, EndJoint, spacing_n, period);    //以定步长插补直线规划运动到终止点  
			return result;
		}
		else
		{
			printf("输入三点相同，无法完成轨迹规划\n");
			no_result[0] = { StartJoint[0],StartJoint[1], StartJoint[2], StartJoint[3], StartJoint[4], StartJoint[5],0,0,0,0,0,0 };
			return no_result;
		}
	}
	else
	{
		unit_v1[0] = v1[0] / Long_v1; unit_v1[1] = v1[1] / Long_v1; unit_v1[1] = v1[1] / Long_v1;
		unit_v2[0] = v2[0] / Long_v2; unit_v2[1] = v2[1] / Long_v2; unit_v2[1] = v2[1] / Long_v2;
		//叉乘求法向量
		unit_n[0] = unit_v1[1] * unit_v2[2] - unit_v2[1] * unit_v1[2];  //y1*z2-y2*z1
		unit_n[1] = unit_v2[0] * unit_v1[2] - unit_v1[0] * unit_v2[2];  //x2*z1-x1*z2
		unit_n[2] = unit_v1[0] * unit_v2[1] - unit_v2[0] * unit_v1[1];  //x1*y2-x2*y1
		double Long_unit_n = sqrt(pow(unit_n[0], 2) + pow(unit_n[1], 2) + pow(unit_n[2], 2));
		if (abs(unit_n[0]) <= 1e-6 && abs(unit_n[1]) <= 1e-6 && abs(unit_n[2]) <= 1e-6)
		{
			printf("输入三点几乎共线，将尝试直线插补");
			result = TrajectoryPlanning::UniformV_CartesianLinePlanning(StartJoint, EndJoint, spacing_n, period);    //以定步长插补直线规划运动到终止点 
			return result;
		}
		else   //三点不重合不共线
		{
			/******************************求解圆弧中心点坐标及半径****************************************/
			Array o(3);//确定圆弧中心坐标
			o = solveCenterPointOfCircle(startcart, midcart, endcart);

			//计算半径
			double R = sqrt(pow((o[0] - startcart[0]), 2) + pow((o[1] - startcart[1]), 2) + pow((o[2] - startcart[2]), 2));

			/*******************在圆弧平面内建立坐标系进行平面圆弧插补，并将插补结果转换至机械臂笛卡尔空间********************/
			double x0 = o[0];	   double y0 = o[1];	 double z0 = o[2];
			double x1 = startcart[0];  double y1 = startcart[1]; double z1 = startcart[2];
			double x2 = midcart[0];	   double y2 = midcart[1];	 double z2 = midcart[2];
			double x3 = endcart[0];	   double y3 = endcart[1];	 double z3 = endcart[2];
			////以垂直与平面的法矢量方向作为新坐标系的W轴方向
			Array W = solvePerpendicularVectorOfCircle(startcart, midcart, endcart);
			double K = sqrt(pow(W[0], 2) + pow(W[1], 2) + pow(W[2], 2));
			double ax = W[0] / K; double ay = W[1] / K; double az = W[2] / K;
			//以OP1方向作为新坐标系的U轴方向
			double nx = (x1 - x0) / R; double ny = (y1 - y0) / R; double nz = (z1 - z0) / R;
			//以UXW作为圆弧平面新坐标的V轴
			double ox = ay * nz - az * ny;
			double oy = az * nx - ax * nz;
			double oz = ax * ny - ay * nx;
			Array_2 T(4, vector<double>(4)), invT(4, vector<double>(4));             //圆弧平面坐标系相对于机械臂基坐标系的位姿关系
			T[0][0] = nx; T[0][1] = ox; T[0][2] = ax; T[0][3] = x0;
			T[1][0] = ny; T[1][1] = oy; T[1][2] = ay; T[1][3] = y0;
			T[2][0] = nz; T[2][1] = oz; T[2][2] = az; T[2][3] = z0;
			T[3][0] = 0;  T[3][1] = 0; T[3][2] = 0; T[3][3] = 1;
			//将机械臂笛卡尔坐标系下圆弧三个关键点坐标转换到圆弧坐标系下
			//matrix_copy(T,invT,4,4);
			invT = inv_matrix(T); //矩阵求逆

			Array_2 P1, P2, P3;  P1 = { {x1},{y1},{z1},{1} }, P2 = { {x2}, {y2},{z2},{1} }, P3 = { {x3},{y3},{z3},{1} };
			Array_2 Q1;				 Q1 = matrix6mul6(invT, P1);
			Array_2 Q2; 			 Q2 = matrix6mul6(invT, P2);
			Array_2 Q3; 			 Q3 = matrix6mul6(invT, P3);
			double theta13 = 0, theta12 = 0;
			//计算角度
			if (Q3[1][0] < 0)
				theta13 = atan2(Q3[1][0], Q3[0][0]) + 2 * PI;
			else theta13 = atan2(Q3[1][0], Q3[0][0]);
			if (Q2[1][0] < 0)
				theta12 = atan2(Q2[1][0], Q2[0][0]) + 2 * PI;
			else theta12 = atan2(Q2[1][0], Q2[0][0]);
			double step = theta13 / spacing_n;

			for (int i = 0; i <= spacing_n; i++)
			{

				all_Q[i][0] = R * cos(i * step);
				all_Q[i][1] = R * sin(i * step);
				all_Q[i][2] = 0;
				all_Q[i][3] = 1;
				double temp[4][1] = { all_Q[i][0],all_Q[i][1],all_Q[i][2],all_Q[i][3] };

				all_P[i] = matrix_mul(T, temp, 1);

			}
		}
	}
	//进行姿态均匀弥散化
	Array_2 allRPY = TrajectoryPlanning::EulerAnglePlanning(StartCoordinate.Roll, StartCoordinate.Pitch, StartCoordinate.Yaw, EndCoordinate.Roll, EndCoordinate.Pitch, EndCoordinate.Yaw, all_P.size());


	int flag;//判断逆解是否在工作范围内
	Array_2 CoordinatePose(spacing_n + 1, vector<double>(6, 0));//所有的位姿结果
	Array_2 Angle(spacing_n + 1, vector<double>(6, 0));//所有的关节角结果
	Array optimal_joint(6);//最优逆解
	map<std::string, Array_2> solutionMap;
	Array cart(6);//笛卡尔坐标数组
	for (int i = 0; i < spacing_n + 1; i++)
	{
		CoordinatePose[i][0] = all_P[i][0];
		CoordinatePose[i][1] = all_P[i][1];
		CoordinatePose[i][2] = all_P[i][2];
		CoordinatePose[i][3] = allRPY[i][0];
		CoordinatePose[i][4] = allRPY[i][1];
		CoordinatePose[i][5] = allRPY[i][2];

	}
	//初始状态
	Angle[0] = StartJoint;
	for (int i = 1; i < spacing_n + 1; i++) {

		map<std::string, Array_2> solutionMap;
		flag = trajKine.inverse_kine(CoordinatePose[i], solutionMap);
		if (flag == -1)
		{
			//FLAG = 1;
			printf("角度超出关节范围The %dth interpolation result reached the joint limit\nJoint position:%f %f %f %f %f %f\n"
				, i, Angle[i - 1][0], Angle[i - 1][1], Angle[i - 1][2], Angle[i - 1][3], Angle[i - 1][4], Angle[i - 1][5]);
			break;
		}//0为正常，1号错误：逆解超出绝对工作范围
		optimal_joint = trajKine.OptimalJoint(solutionMap, Angle[i - 1]);  //将择优解赋给optimal_joint，无解则给Angle[i-1]

		//如果出现关节反转的情况，则停止插补，最后的返回结果为直到极限位置的插补结果
		if ((fabs(optimal_joint[0] - Angle[i - 1][0]) > 30)
			|| (fabs(optimal_joint[1] - Angle[i - 1][1]) > 30)
			|| (fabs(optimal_joint[2] - Angle[i - 1][2]) > 30)
			|| (fabs(optimal_joint[3] - Angle[i - 1][3]) > 30)
			|| (fabs(optimal_joint[4] - Angle[i - 1][4]) > 30)
			|| (fabs(optimal_joint[5] - Angle[i - 1][5]) > 30))    //六个关节前后两次插补相差10°以上则报错
		{
			printf("前后角度超差The %dth interpolation result reached the joint limit\nJoint position:%f %f %f %f %f %f\n"
				, i, Angle[i - 1][0], Angle[i - 1][1], Angle[i - 1][2], Angle[i - 1][3], Angle[i - 1][4], Angle[i - 1][5]);
			printf("逆解角度为:%f %f %f %f %f %f\n", optimal_joint[0], optimal_joint[1], optimal_joint[2], optimal_joint[3], optimal_joint[4], optimal_joint[5]);
			//FLAG = 2;//0为正常，2号错误：终点超出关节角度限制
			break;
		}
		/*将最优解依次赋值给元素*/
		Angle[i] = optimal_joint;
	}
	////速度计算，°每秒
	//// 填充新矩阵的前半部分（角度部分）
	for (std::size_t i = 0; i < Angle.size(); ++i) {
		for (std::size_t j = 0; j < 6; ++j) {
			result[i][j] = Angle[i][j];
		}
	}
	////初速度
	for (int j = 0; j < 6; ++j) {
		result[0][j + 6] = (result[1][j] - result[0][j]) / period;
	}
	////中间速度
	for (int i = 1; i < result.size(); ++i) {
		for (int j = 0; j < 6; ++j) {
			result[i][j + 6] = (result[i][j] - result[i - 1][j]) / period;
		}
	}
	return result;

}
/*	四元数姿态插补
*	输入：起始RPY角，终点RPY角，插补数量
*	输出：RPY角序列
*/
Array_2 TrajectoryPlanning::EulerAnglePlanning(double startRoll, double startPitch, double startYaw, double endRoll, double endPitch, double endYaw, double size)  //始末RPY角和对应位置插补数量
{
	Array quat_start(4, 0.0); Array quat_end(4, 0.0);
	quat_start = angle2quat(startRoll, startPitch, startYaw);//起始四元数wxyz
	quat_end = angle2quat(endRoll, endPitch, endYaw);//终端四元数wxyz

	double cos_a = quat_start[0] * quat_end[0] + quat_start[1] * quat_end[1] + quat_start[2] * quat_end[2] + quat_start[3] * quat_end[3];
	if (cos_a < 0)
	{
		for (int i = 0; i < 4; i++)
		{
			quat_end[i] = -quat_end[i];
		}
	};
	Array_2 All_quat(size, vector<double>(4));
	Array_2 All_RPY(size, vector<double>(3));

	double sin_a = sqrt(1 - pow(cos_a, 2));
	double angle_in_quat = atan2(sin_a, cos_a);         //四元数之间的角度差

	for (int i = 0; i < size; i++)
	{
		double k0 = sin((1 - i / size) * angle_in_quat) / sin_a;
		double k1 = sin((i / size) * angle_in_quat) / sin_a;

		for (int j = 0; j < 4; j++)
		{
			double quat_norm = sqrt(pow((quat_start[0] * k0 + quat_end[0] * k1), 2) + pow((quat_start[1] * k0 + quat_end[1] * k1), 2) + pow((quat_start[2] * k0 + quat_end[2] * k1), 2) + pow((quat_start[3] * k0 + quat_end[3] * k1), 2));
			All_quat[i][j] = (quat_start[j] * k0 + quat_end[j] * k1) / quat_norm;
		}

		All_RPY[i] = quat2angle(All_quat[i][0], All_quat[i][1], All_quat[i][2], All_quat[i][3]); //输入为wxyz，输出为xyz
	}
	return All_RPY;
}



Array_2 TrajectoryPlanning::Point2PointJointPlanning_PutJoint(
	//起始关节
	Array startAngle,
	// 终点坐标
	Array endAngle,
	// 插补周期
	double period)
{
	double v = 2;//最大速度设置
	double a = 0.5;//加速度设置
	std::vector<vector<Data>> Joint(6);//执行关节插补

	int max = 0;
	for (int i = 0; i < 6; i++)
	{
		if ((endAngle[i] - startAngle[i]) < 0)Joint[i] = ComponentsPlanning(startAngle[i], 0, -a, endAngle[i], 0, a, -v, -a, period);
		else Joint[i] = ComponentsPlanning(startAngle[i], 0, a, endAngle[i], 0, -a, v, a, period);
		if (Joint[i].size() > max)max = Joint[i].size();
	}

	Array_2 Angle(max, vector<double>(12, 0));
	for (int i = 0; i < 6; i++)
	{
		for (int j = 0; j < max; j++)
		{
			// 填充关节角度和速度，检查 Joint[i] 的大小
			if (j < Joint[i].size())
			{
				Angle[j][i] = Joint[i][j].positon;
				Angle[j][i + 6] = Joint[i][j].velocity;
			}
			else
			{
				Angle[j][i] = Angle[j - 1][i];
				Angle[j][i + 6] = Angle[j - 1][i + 6];
			}
		}

	}
	return Angle;
}