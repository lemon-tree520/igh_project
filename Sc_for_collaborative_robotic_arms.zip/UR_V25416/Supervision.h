#pragma once
#include <fstream>
#include"TrajectoryPlanning.h"
void printfTXT(Array_2 Data);
void printPUU_TXT(Array_2 PUU);