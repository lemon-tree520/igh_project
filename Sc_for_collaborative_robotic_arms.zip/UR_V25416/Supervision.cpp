#pragma once
#include "Supervision.h"
#include <fstream>
#include"TrajectoryPlanning.h"
#include<iostream>
using namespace std;
void printfTXT(Array_2 Data)
{
    /*
    * TXT输出，每行12个数据，前6个为角度，后6个为角速度
    */
    TrajectoryPlanning tp;
    Array_2 Angle(Data.size(), vector<double>(12));
    std::ofstream outFileA("Angle_output.txt", std::ios::trunc);
    //将角度数组Data扩充为前六个为角度，后六个为速度的二维数组Angle
    for (int i = 0; i < Data.size(); i++)
    {
        for (int j = 0; j < 6; j++)
        {
            Angle[i][j] = Data[i][j];
            if (i == 0)Angle[i][j + 6] = 0;
            else { Angle[i][j + 6] = (Data[i][j] - Data[i - 1][j]) / 0.001; }
        }


    }
    if (outFileA.is_open()) {
        for (int i = 0; i < Data.size(); i++) {
            for (int j = 0; j < 12; j++)
            {
                outFileA << Angle[i][j] << " ";
            }
            outFileA << std::endl;
        }

        // Close the file
        outFileA.close();
        std::cout << "Output written to 'Angle_output.txt'" << std::endl;
    }
    else {
        std::cerr << "Unable to open the file for writing" << std::endl;
    }
    ////////////////////将Data中的角度解转换为坐标解，
    int size = Data.size();
    Array_2 test2(size, vector<double>(6));
    // 填充新矩阵的前半部分（角度部分）
    for (std::size_t i = 0; i < test2.size(); i++) {
        for (std::size_t j = 0; j < 6; j++) {
            test2[i][j] = Data[i][j];
        }
    }
    Array_2 cart(size, vector<double>(6));
    for (int i = 0; i < test2.size(); i++) {
        tp.trajKine.forward_kine(test2[i], cart[i]);
    }
    ///////////////////////输出test矩阵到txt
    std::ofstream outFileC("Cartesian_output.txt", std::ios::trunc);

    if (outFileC.is_open()) {
        // Loop through the transposed array 'test' and write to the file
        for (size_t i = 0; i < cart.size(); i++) {
            for (size_t j = 0; j < 6; j++) {
                outFileC << cart[i][j] << " ";
            }
            outFileC << std::endl;
        }

        // Close the file
        outFileC.close();
        std::cout << "Output written to 'Cartesian_output.txt'" << std::endl;
    }
    else {
        std::cerr << "Unable to open the file for writing" << std::endl;
    }



}
void printPUU_TXT(Array_2 PUU)
{
    std::ofstream outFileB("PUU_output.txt", std::ios::trunc);
    if (outFileB.is_open()) {

        for (size_t i = 0; i < PUU.size(); i++) {
            for (size_t j = 0; j < 6; j++) {
                outFileB << PUU[i][j] << " ";
            }
            outFileB << std::endl;
        }

        // Close the file
        outFileB.close();
        std::cout << "Output written to 'PUU_output.txt'" << std::endl;
    }
    else {
        std::cerr << "Unable to open the file for writing PUU" << std::endl;
    }
    //创建PUU增量文件
    double dPUU = 0;
    std::ofstream outFileD("dPUU_output.txt", std::ios::trunc);
    if (outFileD.is_open()) {

        for (size_t i = 1; i < PUU.size(); i++) {
            for (size_t j = 0; j < 6; j++) {
                dPUU = PUU[i][j] - PUU[i - 1][j];
                outFileD << dPUU << " ";
            }
            outFileD << std::endl;
        }

        // Close the file
        outFileD.close();
        std::cout << "Output written to 'dPUU_output.txt'" << std::endl;
    }
    else {
        std::cerr << "Unable to open the file for writing dPUU" << std::endl;
    }

}