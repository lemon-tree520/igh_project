#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <stdbool.h>
#include <signal.h>
#include <sys/mman.h>
#include <time.h>
#include <sys/resource.h>
#include <errno.h>
#include "ecrt.h"

#define FREQUENCY 1000     //1ms周期
#define CLOCK_TO_USE 1

#define NSEC_PER_SEC (1000000000)
//任务周期,单位ns
#define PERIOD_NS (NSEC_PER_SEC / FREQUENCY)

#define DIFF_NS(A, B) (((B).tv_sec - (A).tv_sec) * NSEC_PER_SEC + \
	(B).tv_nsec - (A).tv_nsec)

#define TIMESPEC2NS(T) ((uint64_t) (T).tv_sec * NSEC_PER_SEC + (T).tv_nsec)


#define SLAVE_NUM                           6
#define MOTOR_MODEL_CONTROL_WORD_HALT       0x1 << 8

#define SLAVE_0_ALIAS                 1
#define SLAVE_0_POSITION              0
#define SLAVE_0_VID_PID               0x000001dd, 0x00006010
#define SLAVE_1_ALIAS                 2
#define SLAVE_1_POSITION              0
#define SLAVE_1_VID_PID               0x00666999, 0x00004806
#define SLAVE_2_ALIAS                 3
#define SLAVE_2_POSITION              0
#define SLAVE_2_VID_PID               0x00666999, 0x00004806
#define SLAVE_3_ALIAS                 4
#define SLAVE_3_POSITION              0
#define SLAVE_3_VID_PID               0x00666999, 0x00004806
#define SLAVE_4_ALIAS                 5
#define SLAVE_4_POSITION              0
#define SLAVE_4_VID_PID               0x00666999, 0x00004806
#define SLAVE_5_ALIAS                 6
#define SLAVE_5_POSITION              0
#define SLAVE_5_VID_PID               0x00666999, 0x00004806

static struct _SlaveOffset {
    unsigned int ctrl_word;
    signed int target_speed;
    unsigned int mode_operation;
    unsigned int digital_outputs;

    unsigned int status_word;
    signed int current_speed;
    unsigned int digital_inputs;
    unsigned int modes_of_operation_display;
} slave_offset[SLAVE_NUM];

struct _SlaveInfo {
    uint32_t alias;
    uint32_t position;
    uint32_t vendor_id;
    uint32_t product_code;
};

struct _SlaveConfig {
    ec_slave_config_t       *sc;
    ec_slave_config_state_t sc_state;
    struct _SlaveOffset     offset;
    int                     cur_speed;
};

struct _Domain {
    ec_domain_t         *domain;
    ec_domain_state_t   domain_state;
    uint8_t             *domain_pd;
};

const static ec_pdo_entry_reg_t domain_regs[] = {
    /* Slave 0 */
    {SLAVE_0_ALIAS, SLAVE_0_POSITION, SLAVE_0_VID_PID, 0x6040, 0, &slave_offset[0].ctrl_word},
    {SLAVE_0_ALIAS, SLAVE_0_POSITION, SLAVE_0_VID_PID, 0x60ff, 0, &slave_offset[0].target_speed},
    {SLAVE_0_ALIAS, SLAVE_0_POSITION, SLAVE_0_VID_PID, 0x6060, 0, &slave_offset[0].mode_operation},
    {SLAVE_0_ALIAS, SLAVE_0_POSITION, SLAVE_0_VID_PID, 0x60fe, 1, &slave_offset[0].digital_outputs},

    {SLAVE_0_ALIAS, SLAVE_0_POSITION, SLAVE_0_VID_PID, 0x6041, 0, &slave_offset[0].status_word},
    {SLAVE_0_ALIAS, SLAVE_0_POSITION, SLAVE_0_VID_PID, 0x6061, 0, &slave_offset[0].modes_of_operation_display},
    {SLAVE_0_ALIAS, SLAVE_0_POSITION, SLAVE_0_VID_PID, 0x606C, 0, &slave_offset[0].current_speed},  
    {SLAVE_0_ALIAS, SLAVE_0_POSITION, SLAVE_0_VID_PID, 0x60FD, 0, &slave_offset[0].digital_inputs},
    /*Slave 1 */
    {SLAVE_1_ALIAS, SLAVE_1_POSITION, SLAVE_1_VID_PID, 0x6040, 0, &slave_offset[1].ctrl_word},
    {SLAVE_1_ALIAS, SLAVE_1_POSITION, SLAVE_1_VID_PID, 0x60FF, 0, &slave_offset[1].target_speed},
    {SLAVE_1_ALIAS, SLAVE_1_POSITION, SLAVE_1_VID_PID, 0x6060, 0, &slave_offset[1].mode_operation},
    {SLAVE_1_ALIAS, SLAVE_1_POSITION, SLAVE_1_VID_PID, 0x60fe, 1, &slave_offset[1].digital_outputs},

    {SLAVE_1_ALIAS, SLAVE_1_POSITION, SLAVE_1_VID_PID, 0x6041, 0, &slave_offset[1].status_word},
    {SLAVE_1_ALIAS, SLAVE_1_POSITION, SLAVE_1_VID_PID, 0x6061, 0, &slave_offset[1].modes_of_operation_display},
    {SLAVE_1_ALIAS, SLAVE_1_POSITION, SLAVE_1_VID_PID, 0x606C, 0, &slave_offset[1].current_speed},
    {SLAVE_1_ALIAS, SLAVE_1_POSITION, SLAVE_1_VID_PID, 0x60FD, 0, &slave_offset[1].digital_inputs},
    /* Slave 2*/
    {SLAVE_2_ALIAS, SLAVE_2_POSITION, SLAVE_2_VID_PID, 0x6040, 0, &slave_offset[2].ctrl_word},
    {SLAVE_2_ALIAS, SLAVE_2_POSITION, SLAVE_2_VID_PID, 0x60FF, 0, &slave_offset[2].target_speed},
    {SLAVE_2_ALIAS, SLAVE_2_POSITION, SLAVE_2_VID_PID, 0x6060, 0, &slave_offset[2].mode_operation},
    {SLAVE_2_ALIAS, SLAVE_2_POSITION, SLAVE_2_VID_PID, 0x60fe, 1, &slave_offset[2].digital_outputs},

    {SLAVE_2_ALIAS, SLAVE_2_POSITION, SLAVE_2_VID_PID, 0x6041, 0, &slave_offset[2].status_word},
    {SLAVE_2_ALIAS, SLAVE_2_POSITION, SLAVE_2_VID_PID, 0x6061, 0, &slave_offset[2].modes_of_operation_display},
    {SLAVE_2_ALIAS, SLAVE_2_POSITION, SLAVE_2_VID_PID, 0x606C, 0, &slave_offset[2].current_speed},
    {SLAVE_2_ALIAS, SLAVE_2_POSITION, SLAVE_2_VID_PID, 0x60FD, 0, &slave_offset[2].digital_inputs}, 
    /* Slave 3 */
    {SLAVE_3_ALIAS, SLAVE_3_POSITION, SLAVE_3_VID_PID, 0x6040, 0, &slave_offset[3].ctrl_word},
    {SLAVE_3_ALIAS, SLAVE_3_POSITION, SLAVE_3_VID_PID, 0x60FF, 0, &slave_offset[3].target_speed},
    {SLAVE_3_ALIAS, SLAVE_3_POSITION, SLAVE_3_VID_PID, 0x6060, 0, &slave_offset[3].mode_operation},
    {SLAVE_3_ALIAS, SLAVE_3_POSITION, SLAVE_3_VID_PID, 0x60fe, 1, &slave_offset[3].digital_outputs},

    {SLAVE_3_ALIAS, SLAVE_3_POSITION, SLAVE_3_VID_PID, 0x6041, 0, &slave_offset[3].status_word},
    {SLAVE_3_ALIAS, SLAVE_3_POSITION, SLAVE_3_VID_PID, 0x6061, 0, &slave_offset[3].modes_of_operation_display},
    {SLAVE_3_ALIAS, SLAVE_3_POSITION, SLAVE_3_VID_PID, 0x606C, 0, &slave_offset[3].current_speed},
    {SLAVE_3_ALIAS, SLAVE_3_POSITION, SLAVE_3_VID_PID, 0x60FD, 0, &slave_offset[3].digital_inputs},
    
    /* Slave 4 */
    {SLAVE_4_ALIAS, SLAVE_4_POSITION, SLAVE_4_VID_PID, 0x6040, 0, &slave_offset[4].ctrl_word},
    {SLAVE_4_ALIAS, SLAVE_4_POSITION, SLAVE_4_VID_PID, 0x60FF, 0, &slave_offset[4].target_speed},
    {SLAVE_4_ALIAS, SLAVE_4_POSITION, SLAVE_4_VID_PID, 0x6060, 0, &slave_offset[4].mode_operation},
    {SLAVE_4_ALIAS, SLAVE_4_POSITION, SLAVE_4_VID_PID, 0x60fe, 1, &slave_offset[4].digital_outputs},

    {SLAVE_4_ALIAS, SLAVE_4_POSITION, SLAVE_4_VID_PID, 0x6041, 0, &slave_offset[4].status_word},
    {SLAVE_4_ALIAS, SLAVE_4_POSITION, SLAVE_4_VID_PID, 0x6061, 0, &slave_offset[4].modes_of_operation_display},
    {SLAVE_4_ALIAS, SLAVE_4_POSITION, SLAVE_4_VID_PID, 0x606C, 0, &slave_offset[4].current_speed},
    {SLAVE_4_ALIAS, SLAVE_4_POSITION, SLAVE_4_VID_PID, 0x60FD, 0, &slave_offset[4].digital_inputs},

        /* Slave 4 */
    {SLAVE_5_ALIAS, SLAVE_5_POSITION, SLAVE_5_VID_PID, 0x6040, 0, &slave_offset[5].ctrl_word},
    {SLAVE_5_ALIAS, SLAVE_5_POSITION, SLAVE_5_VID_PID, 0x60FF, 0, &slave_offset[5].target_speed},
    {SLAVE_5_ALIAS, SLAVE_5_POSITION, SLAVE_5_VID_PID, 0x6060, 0, &slave_offset[5].mode_operation},
    {SLAVE_5_ALIAS, SLAVE_5_POSITION, SLAVE_5_VID_PID, 0x60fe, 1, &slave_offset[5].digital_outputs},

    {SLAVE_5_ALIAS, SLAVE_5_POSITION, SLAVE_5_VID_PID, 0x6041, 0, &slave_offset[5].status_word},
    {SLAVE_5_ALIAS, SLAVE_5_POSITION, SLAVE_5_VID_PID, 0x6061, 0, &slave_offset[5].modes_of_operation_display},
    {SLAVE_5_ALIAS, SLAVE_5_POSITION, SLAVE_5_VID_PID, 0x606C, 0, &slave_offset[5].current_speed},
    {SLAVE_5_ALIAS, SLAVE_5_POSITION, SLAVE_5_VID_PID, 0x60FD, 0, &slave_offset[5].digital_inputs},
    {}
};

ec_pdo_entry_info_t slave_pdo_entries[] = {
    {0x6040, 0x00, 16}, /* Controlword */
    {0x6060, 0x00, 8}, /* Modes_of_operation */
    //{0x0000, 0x00, 8},
    {0x60ff, 0x00, 32}, /* Target_velocity */
    {0x60fe, 0x01, 32}, /* Digital_outputs_Physical_outputs */

    {0x6041, 0x00, 16}, /* Statusword */
    {0x6061, 0x00, 8}, /* Modes_of_operation_display */
    //{0x0000, 0x00, 8},
    {0x606c, 0x00, 32}, /* Velocity_actual_value */
    {0x60fd, 0x00, 32}, /* Digital_inputs */
};

 ec_pdo_info_t slave_pdos[] = {
    {0x1601, 4, slave_pdo_entries + 0}, /* Obj0x1601 */
    {0x1a01, 4, slave_pdo_entries + 4}, /* Obj0x1A01 */
};

ec_sync_info_t slave_syncs[] = {
    {0, EC_DIR_OUTPUT, 0, NULL, EC_WD_DISABLE},
    {1, EC_DIR_INPUT, 0, NULL, EC_WD_DISABLE},
    {2, EC_DIR_OUTPUT, 1, slave_pdos + 0, EC_WD_ENABLE},
    {3, EC_DIR_INPUT, 1, slave_pdos + 1, EC_WD_DISABLE},
    {0xff}
};

struct _SlaveInfo slave_info[] = {
    {SLAVE_0_ALIAS, SLAVE_0_POSITION, SLAVE_0_VID_PID},
    {SLAVE_1_ALIAS, SLAVE_1_POSITION, SLAVE_1_VID_PID},
    {SLAVE_2_ALIAS, SLAVE_2_POSITION, SLAVE_2_VID_PID},
    {SLAVE_3_ALIAS, SLAVE_3_POSITION, SLAVE_3_VID_PID},
    {SLAVE_4_ALIAS, SLAVE_4_POSITION, SLAVE_4_VID_PID},
    {SLAVE_5_ALIAS, SLAVE_5_POSITION, SLAVE_5_VID_PID},
};

static ec_master_t          *master = NULL;
static ec_master_state_t    master_state = {};
struct _Domain domain;
const struct timespec cycletime = {0, PERIOD_NS};

void check_domain_state(struct _Domain *domain)
{
    ec_domain_state_t ds;
    ecrt_domain_state(domain->domain, &ds);

    if (ds.working_counter != domain->domain_state.working_counter) {
        printf("--> check_domain_state: Domain: WC %u.\n", ds.working_counter);
    }

    if (ds.wc_state != domain->domain_state.wc_state) {
        printf("--> check_domain_state: Domain: State %u.\n", ds.wc_state);
    }

    domain->domain_state = ds;
}

struct timespec timespec_add(struct timespec time1, struct timespec time2)
{
	struct timespec result;

	if ((time1.tv_nsec + time2.tv_nsec) >= NSEC_PER_SEC) {
		result.tv_sec = time1.tv_sec + time2.tv_sec + 1;
		result.tv_nsec = time1.tv_nsec + time2.tv_nsec - NSEC_PER_SEC;
	} else {
		result.tv_sec = time1.tv_sec + time2.tv_sec;
		result.tv_nsec = time1.tv_nsec + time2.tv_nsec;
	}

	return result;
}

void check_master_state()
{
    ec_master_state_t ms;
    ecrt_master_state(master, &ms);

	if (ms.slaves_responding != master_state.slaves_responding) {
        printf("--> check_master_state: %u slave(s).\n", ms.slaves_responding);
    }

    if (ms.al_states != master_state.al_states) {
        printf("--> check_master_state: AL states: 0x%02X.\n", ms.al_states);
    }

    if (ms.link_up != master_state.link_up) {
        printf("--> check_master_state: Link is %s.\n", ms.link_up ? "up" : "down");
    }

    master_state = ms;
}

void check_slave_config_state(struct _SlaveConfig *slave_config)
{
    ec_slave_config_state_t s;
    int i;
    for (i = 0; i < SLAVE_NUM; i++) {
    memset(&s, 0, sizeof(s));
    ecrt_slave_config_state(slave_config[i].sc, &s);
    if (s.al_state != slave_config[i].sc_state.al_state) {
        printf("--> check_slave_config_state: slave[%d]: State 0x%02X.\n", i,s.al_state);
    }

    if (s.online != slave_config[i].sc_state.online) {
        printf("--> check_slave_config_state: slave[%d]: %s.\n", i, s.online ? "online" : "offline");
    }
    if (s.operational != slave_config[i].sc_state.operational) {
        printf("--> check_slave_config_state: slave[%d]: %soperational.\n", i, s.operational ? "" : "Not ");
    }
        slave_config[i].sc_state = s;
    }
}



void cyclic_task(struct _SlaveConfig *slave_config, struct _Domain *domain)
{
    struct timespec wakeupTime;
    int i= 1;
    unsigned int blink = 0;
    clock_gettime(CLOCK_TO_USE, &wakeupTime);

    while (1) 
    {
		wakeupTime = timespec_add(wakeupTime, cycletime);
        clock_nanosleep(CLOCK_TO_USE,1, &wakeupTime, NULL);

        ecrt_master_receive(master);
        ecrt_domain_process(domain->domain);

        check_domain_state(domain);

        ecrt_master_receive(master);
        ecrt_domain_process(domain->domain);
        check_domain_state(domain);
        check_master_state();
        check_slave_config_state(slave_config);
        //每10ms翻转一次电平
        if(!(i%10))
        {
            blink = !blink;
        }
        //printf("blink = %d\r\n",blink);
        EC_WRITE_U32(domain->domain_pd + slave_offset[0].digital_outputs,blink ? 0x00 : 0x10000);
        EC_WRITE_U32(domain->domain_pd + slave_offset[1].digital_outputs,blink ? 0x00 : 0x10000);
        EC_WRITE_U32(domain->domain_pd + slave_offset[2].digital_outputs,blink ? 0x00 : 0x10000);
        EC_WRITE_U32(domain->domain_pd + slave_offset[3].digital_outputs,blink ? 0x00 : 0x10000);
        EC_WRITE_U32(domain->domain_pd + slave_offset[4].digital_outputs,blink ? 0x00 : 0x10000);
        EC_WRITE_U32(domain->domain_pd + slave_offset[5].digital_outputs,blink ? 0x00 : 0x10000);
       
        ecrt_domain_queue(domain->domain);
        ecrt_master_send(master);
        i++;
    }
}

int main(int argc, char **argv)
{
    int status = 0, ret = -1;
    int i;
    struct _SlaveConfig slave_config[SLAVE_NUM];

    master = ecrt_request_master(0);
    if (!master) {
        printf("--> main: Request master failed.\n");
        return -1;
    }
    printf("--> main: Request master success.\n");

    memset(&slave_config, 0, sizeof(slave_config));
    memset(&domain, 0, sizeof(domain));

    domain.domain = ecrt_master_create_domain(master);
    if (!domain.domain) {
        status = -1;
        printf("--> main: Create domain failed.\n");
        goto err_leave;
    }
    printf("--> main: Create domain success.\n");

    for (i = 0; i < SLAVE_NUM; i++) {
        slave_config[i].sc = ecrt_master_slave_config(master, slave_info[i].alias,
                    slave_info[i].position, slave_info[i].vendor_id,
                    slave_info[i].product_code);
        if (!slave_config[i].sc) {
            status = -1;
            printf("--> main: Get slave configuration failed.\n");
            goto err_leave;
        }
    }
    printf("--> main: Get slave configuration success.\n");

    for (i = 0; i < SLAVE_NUM; i++) {
        ret = ecrt_slave_config_pdos(slave_config[i].sc, EC_END, slave_syncs);
        if (ret != 0) {
            status = -1;
            printf("--> main: Configuration PDO failed.\n");
            goto err_leave;
        }
    }
    printf("--> main: Configuration PDO success.\n");

    ret = ecrt_domain_reg_pdo_entry_list(domain.domain, domain_regs);
    if (ret != 0) {
        status = -1;
        printf("--> main: Failed to register bunch of PDO entries for domain.\n");
        goto err_leave;
    }
    printf("--> main: success to register bunch of PDO entries for domain.\n");

    ret = ecrt_master_activate(master);
    if (ret < 0) {
        status = -1;
        printf("--> main: Activate master failed.\n");
        goto err_leave;
    }
    printf("--> main: Activate master success.\n");

    domain.domain_pd = ecrt_domain_data(domain.domain);
    if (!domain.domain_pd) {
        status = -1;
        printf("--> main: Get pointer to the process data memory failed.\n");
        goto err_leave;
    }
    printf("--> main: Get pointer to the process data memory success.\n");

    /* Prio is a value in the range -20 to 19, set -19 with highest priority. */
    __pid_t pid = getpid();
    if (setpriority(PRIO_PROCESS, pid, -19))
        printf("--> main: Warning: Failed to set priority: %s\n", strerror(errno));

    /* Start cyclic function. */
    printf("--> main: Enter cycle task now...\n");
    signal(SIGINT,signalHandler);
    cyclic_task(slave_config, &domain);
err_leave:
	/* Releases EtherCAT master */
	ecrt_release_master(master);
	printf("--> main: Release master.\n");

	return status;
}